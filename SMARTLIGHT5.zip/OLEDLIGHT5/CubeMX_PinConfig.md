# STM32F407VET6 + RT-Thread Studio + CubeMX 引脚配置

## 1. 时钟建议

- HSE: Crystal/Ceramic Resonator，按开发板实际晶振设置，常见为 8 MHz。
- SYSCLK: 168 MHz。
- APB1 Prescaler: /4，PCLK1 = 42 MHz，TIM2/TIM3 定时器时钟 = 84 MHz。
- APB2 Prescaler: /2，PCLK2 = 84 MHz。

## 2. 必选引脚表

| 功能 | STM32 引脚 | CubeMX 模式 | 说明 |
|---|---|---|---|
| LED PWM | PA2 | TIM2_CH3 / PWM Generation CH3 | 输出 PWM 控制 LED 亮度 |
| 编码器 A 相 | PA6 | TIM3_CH1 | 手动调光输入 |
| 编码器 B 相 | PA7 | TIM3_CH2 | 手动调光输入 |
| BH1750 SCL | PB6 | I2C1_SCL | BH1750 光照传感器 |
| BH1750 SDA | PB7 | I2C1_SDA | BH1750 光照传感器 |
| OLED SCL | PA8 | I2C3_SCL | SSD1306/SSD1315 OLED |
| OLED SDA | PC9 | I2C3_SDA | SSD1306/SSD1315 OLED |
| 模式按键 | PB0 | GPIO_Input / Pull-up | AUTO/MANUAL 模式切换，按下接 GND |
| 调试下载 | PA13/PA14 | SWDIO/SWCLK | ST-Link 下载调试 |

## 3. TIM2 PWM 配置

- Pinout: PA2 选择 `TIM2_CH3`。
- TIM2 Mode: `PWM Generation CH3`。
- Prescaler: 可以由代码动态计算；如果在 CubeMX 固定填，84 MHz 定时器时钟下填 `83`。
- Counter Period: `999`。
- PWM Mode: PWM mode 1。
- Pulse: `0`。
- Polarity: High。

代码会把 TIM2 计数频率设置为 1 MHz，Period 为 999，因此 PWM 频率为 1 kHz，占空比为 0%~100%。

## 4. TIM3 编码器配置

- Pinout: PA6 选择 `TIM3_CH1`，PA7 选择 `TIM3_CH2`。
- TIM3 Mode: `Encoder Mode`。
- Encoder Mode: `Encoder Mode TI1 and TI2`。
- Counter Period: `65535`。
- IC1/IC2 Polarity: Rising Edge。
- IC1/IC2 Selection: Direct TI。
- IC1/IC2 Filter: `8`。

## 5. I2C1 / BH1750 配置

- PB6: I2C1_SCL。
- PB7: I2C1_SDA。
- I2C Speed: 100 kHz 或 400 kHz 均可，推荐先用 100 kHz。
- GPIO: Open Drain，上拉。模块如果没有板载上拉，需要外接 4.7k~10k 上拉到 3.3V。
- BH1750 ADDR 接 GND 时地址为 0x23；接 VCC 时地址为 0x5C，需要同步修改 `applications/bh1750.h`。

RT-Thread Studio 里需要启用：

```c
#define RT_USING_I2C
#define BSP_USING_I2C1
```

## 6. I2C3 / OLED 配置

- PA8: I2C3_SCL。
- PC9: I2C3_SDA。
- I2C Speed: 100 kHz 或 400 kHz。
- OLED 地址：默认 7 位地址 0x3C。

RT-Thread Studio 里需要启用：

```c
#define RT_USING_I2C
#define BSP_USING_I2C3
```

## 7. PB0 模式切换按键

- PB0: GPIO_Input。
- Pull-up: Enable。
- 硬件接法：PB0 一端接按键，按键另一端接 GND。
- 代码逻辑：检测高电平到低电平的下降沿，并做 200 ms 软件消抖。

## 8. 编译注意事项

1. 删除或排除旧的 `main.c`、旧 `pwm_led.c`，避免重复定义 `main()`、`htim2`、`htim3`。
2. 把本项目 `applications/` 目录复制到 RT-Thread Studio 工程同名目录。
3. 确认 `applications/SConscript` 已被工程构建系统包含。
4. 若 OLED 或 BH1750 没响应，先确认 RT-Thread 控制台里是否能找到 `i2c1`、`i2c3` 设备。
