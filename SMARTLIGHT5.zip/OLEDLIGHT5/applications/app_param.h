#ifndef __APP_PARAM_H__
#define __APP_PARAM_H__

#include <rtthread.h>

/*
 * 台灯掉电保存参数。
 * 注意：mode 使用 main.c 中 app_mode_t 对应的数值：
 * 0 = 自动，1 = 手动亮度，2 = 手动色温。
 */
typedef struct
{
    int mode;
    int manual_brightness;
    int manual_cct;
} app_param_t;

void app_param_set_default(app_param_t *param);
void app_param_sanitize(app_param_t *param);
rt_bool_t app_param_equal(const app_param_t *a, const app_param_t *b);

int app_param_init(void);
int app_param_load(app_param_t *param);
int app_param_save(const app_param_t *param);

#endif /* __APP_PARAM_H__ */
