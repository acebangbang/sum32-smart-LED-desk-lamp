/*
 * oled.h
 */
#ifndef __OLED_H
#define __OLED_H

#include <rtthread.h>
#include <rtdevice.h>
#include <stdint.h>
#include "board.h"

// I2C 总线设备名称 (改为 I2C3)
#define OLED_I2C_BUS_NAME       "i2c3"

// SSD1315 驱动芯片在 I2C 模式下的地址 (0x78)
// SA0 接地时 7 位地址为 0x3C，左移一位为 0x78
#define OLED_ADDR  0x3C

// OLED 屏幕尺寸定义
#define OLED_WIDTH              128
#define OLED_HEIGHT             64

// 命令/数据控制字节定义
#define OLED_CMD_MODE            0x00
#define OLED_DATA_MODE           0x40

/* 函数声明 */
int oled_write_cmd(uint8_t cmd);
int oled_write_data(uint8_t data);

void oled_init(void);
void oled_full_ram(uint8_t data);
void oled_set_pos(uint8_t x, uint8_t y);

void oled_display_on(void);
void oled_display_off(void);
void oled_show_char(uint8_t x, uint8_t y, uint8_t chr);
void oled_show_string(uint8_t x, uint8_t y, const char *str);
void oled_clear(void);

/* 16 点阵 UTF-8 中文显示：中文占 16x16，ASCII 仍使用原 6x8 字库 */
void oled_show_hz16_char(uint8_t x, uint8_t y_page, uint32_t unicode);
void oled_show_utf8_string(uint8_t x, uint8_t y_page, const char *str);
void oled_clear_line16(uint8_t y_page);

#endif /* __OLED_H */
