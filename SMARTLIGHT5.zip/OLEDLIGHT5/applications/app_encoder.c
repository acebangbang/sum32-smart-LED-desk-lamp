#include "app_encoder.h"
#include "app_config.h"

TIM_HandleTypeDef htim3;
static uint16_t g_last_count = 0;
static int32_t g_encoder_accum = 0;

#ifndef ENCODER_COUNTS_PER_STEP
#define ENCODER_COUNTS_PER_STEP 4
#endif

static void encoder_gpio_init(void)
{
    GPIO_InitTypeDef GPIO_InitStruct = {0};

    __HAL_RCC_GPIOA_CLK_ENABLE();
    __HAL_RCC_TIM3_CLK_ENABLE();

    /* PA6 -> TIM3_CH1, PA7 -> TIM3_CH2, AF2 */
    GPIO_InitStruct.Pin       = GPIO_PIN_6 | GPIO_PIN_7;
    GPIO_InitStruct.Mode      = GPIO_MODE_AF_PP;
    GPIO_InitStruct.Pull      = GPIO_PULLUP;
    GPIO_InitStruct.Speed     = GPIO_SPEED_FREQ_LOW;
    GPIO_InitStruct.Alternate = GPIO_AF2_TIM3;
    HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);
}

int encoder_init(void)
{
    TIM_Encoder_InitTypeDef sConfig = {0};
    TIM_MasterConfigTypeDef sMasterConfig = {0};

    encoder_gpio_init();

    htim3.Instance = TIM3;
    htim3.Init.Prescaler = 0;
    htim3.Init.CounterMode = TIM_COUNTERMODE_UP;
    htim3.Init.Period = 0xFFFF;
    htim3.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
    htim3.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;

    sConfig.EncoderMode = TIM_ENCODERMODE_TI12;
    sConfig.IC1Polarity = TIM_ICPOLARITY_RISING;
    sConfig.IC1Selection = TIM_ICSELECTION_DIRECTTI;
    sConfig.IC1Prescaler = TIM_ICPSC_DIV1;
    sConfig.IC1Filter = ENCODER_FILTER;
    sConfig.IC2Polarity = TIM_ICPOLARITY_RISING;
    sConfig.IC2Selection = TIM_ICSELECTION_DIRECTTI;
    sConfig.IC2Prescaler = TIM_ICPSC_DIV1;
    sConfig.IC2Filter = ENCODER_FILTER;

    if (HAL_TIM_Encoder_Init(&htim3, &sConfig) != HAL_OK)
    {
        rt_kprintf("TIM3 encoder init failed\r\n");
        return -RT_ERROR;
    }

    sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
    sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
    if (HAL_TIMEx_MasterConfigSynchronization(&htim3, &sMasterConfig) != HAL_OK)
    {
        rt_kprintf("TIM3 master config failed\r\n");
        return -RT_ERROR;
    }

    if (HAL_TIM_Encoder_Start(&htim3, TIM_CHANNEL_ALL) != HAL_OK)
    {
        rt_kprintf("TIM3 encoder start failed\r\n");
        return -RT_ERROR;
    }

    __HAL_TIM_SET_COUNTER(&htim3, 0);
    g_last_count = __HAL_TIM_GET_COUNTER(&htim3);
    g_encoder_accum = 0;

    rt_kprintf("Encoder ready: PA6 TIM3_CH1, PA7 TIM3_CH2, %d counts/step\r\n", ENCODER_COUNTS_PER_STEP);
    return RT_EOK;
}

int encoder_get_delta(void)
{
    uint16_t current = __HAL_TIM_GET_COUNTER(&htim3);
    int16_t raw_delta = (int16_t)(current - g_last_count);
    int step = 0;

    g_last_count = current;

    if (raw_delta == 0)
    {
        return 0;
    }

    /*
     * TIM 编码器模式读到的是原始边沿计数。
     * 常见机械编码器一格会产生多个计数，因此这里先累计，
     * 每 ENCODER_COUNTS_PER_STEP 个原始计数才输出 1 个 UI 步进。
     */
    g_encoder_accum += raw_delta;

    while (g_encoder_accum >= ENCODER_COUNTS_PER_STEP)
    {
        step++;
        g_encoder_accum -= ENCODER_COUNTS_PER_STEP;
    }

    while (g_encoder_accum <= -ENCODER_COUNTS_PER_STEP)
    {
        step--;
        g_encoder_accum += ENCODER_COUNTS_PER_STEP;
    }

    /* 菜单/亮度/色温一次最多走一步，避免一格跳多项 */
    if (step > 1) step = 1;
    if (step < -1) step = -1;

    return step;
}
