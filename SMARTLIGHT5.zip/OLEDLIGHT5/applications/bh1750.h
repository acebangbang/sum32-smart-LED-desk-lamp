#ifndef __BH1750_H__
#define __BH1750_H__

#include <rtthread.h>
#include <rtdevice.h>

#define BH1750_I2C_BUS_NAME     "i2c1"

/* ADDR 接 GND 时为 0x23；ADDR 接 VCC 时改成 0x5C */
#define BH1750_ADDR             0x23

typedef enum
{
    BH1750_POWER_OFF    = 0x00,
    BH1750_POWER_ON     = 0x01,
    BH1750_RESET        = 0x07,
    BH1750_CONT_H_MODE  = 0x10,
    BH1750_CONT_H_MODE2 = 0x11,
    BH1750_CONT_L_MODE  = 0x13,
    BH1750_ONCE_H_MODE  = 0x20,
    BH1750_ONCE_H_MODE2 = 0x21,
    BH1750_ONCE_L_MODE  = 0x23
} bh1750_cmd_t;

int bh1750_init(void);
rt_err_t bh1750_read_lux(float *lux);

#endif
