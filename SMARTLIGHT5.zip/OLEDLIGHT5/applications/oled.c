/*
 * oled.c
 */
#include "oled.h"
#include "oledfont.h"
#include <rtthread.h>
#include <rtdevice.h>
#include <string.h>

// 定义全局 I2C 设备句柄
static struct rt_i2c_bus_device *i2c_bus = RT_NULL;

/*
 * 功能：向 OLED 发送一个命令字节
 * 实现：使用 RT-Thread 标准 I2C 接口 rt_i2c_master_send()
 */
int oled_write_cmd(uint8_t cmd)
{
    struct rt_i2c_msg msgs[2]; // I2C 消息结构体
    uint8_t send_buf[2] = {OLED_CMD_MODE, cmd}; // 填充命令控制字节和命令内容

    // 配置要发送的 I2C 消息
    msgs[0].addr  = OLED_ADDR;
    msgs[0].flags = RT_I2C_WR;          // 写操作
    msgs[0].buf   = send_buf;
    msgs[0].len   = 2;                  // 发送2个字节

    // 调用 RT-Thread 的 I2C 传输函数，这里只发送一条消息
    if (rt_i2c_transfer(i2c_bus, &msgs[0], 1) == 1) {
        return RT_EOK;
    } else {
        rt_kprintf("I2C CMD write failed! \n");
        return -RT_ERROR;
    }
}

/*
 * 功能：向 OLED 发送一个数据字节 (写入 GDDRAM)
 * 实现：使用 RT-Thread 标准 I2C 接口 rt_i2c_master_send()
 */
int oled_write_data(uint8_t data)
{
    struct rt_i2c_msg msgs[1];
    uint8_t send_buf[2] = {OLED_DATA_MODE, data}; // 填充数据控制字节和数据内容

    // 配置要发送的 I2C 消息
    msgs[0].addr  = OLED_ADDR;
    msgs[0].flags = RT_I2C_WR;
    msgs[0].buf   = send_buf;
    msgs[0].len   = 2;

    if (rt_i2c_transfer(i2c_bus, &msgs[0], 1) == 1) {
        return RT_EOK;
    } else {
        rt_kprintf("I2C DATA write failed! \n");
        return -RT_ERROR;
    }
}

/*
 * 功能：OLED 官方推荐的初始化流程
 * 说明：此序列参考 SSD1315 数据手册，包含关闭显示、设置对比度、扫描方向等关键步骤
 */
void oled_init(void)
{
    // 1. 查找并打开 I2C 总线设备
    i2c_bus = (struct rt_i2c_bus_device *)rt_device_find(OLED_I2C_BUS_NAME);
    if (i2c_bus == RT_NULL) {
        rt_kprintf("Can't find %s device!\n", OLED_I2C_BUS_NAME);
        return;
    }

    // 2. SSD1315 官方初始化序列 (务必严格遵循)
    oled_write_cmd(0xAE); // Display OFF

    oled_write_cmd(0xD5); // Set Display Clock Divide Ratio/Oscillator Frequency
    oled_write_cmd(0x80); // Default value

    oled_write_cmd(0xA8); // Set Multiplex Ratio
    oled_write_cmd(0x3F); // 64MUX

    oled_write_cmd(0xD3); // Set Display Offset
    oled_write_cmd(0x00); // 0 offset

    oled_write_cmd(0x40); // Set Display Start Line to 0

    oled_write_cmd(0x8D); // Charge Pump Setting
    oled_write_cmd(0x14); // Enable charge pump (0x14 for 7.5V, 0x95 for 9V)

    oled_write_cmd(0x20); // Set Memory Addressing Mode
    oled_write_cmd(0x02); // Page Addressing Mode

    oled_write_cmd(0xA1); // Set Segment Re-map (Column 127 mapped to SEG0)
    oled_write_cmd(0xC8); // Set COM Output Scan Direction (Remapped mode)

    oled_write_cmd(0xDA); // Set COM Pins Hardware Configuration
    oled_write_cmd(0x12); // Alternative COM pin config, Disable Left/Right remap

    oled_write_cmd(0x81); // Set Contrast Control
    oled_write_cmd(0xCF); // Contrast value (0x00~0xFF)

    oled_write_cmd(0xD9); // Set Pre-charge Period
    oled_write_cmd(0xF1); // Default value

    oled_write_cmd(0xDB); // Set VCOMH Deselect Level
    oled_write_cmd(0x40); // ~0.77 x VCC

    oled_write_cmd(0xA4); // Entire Display ON (Resume to RAM content display)
    oled_write_cmd(0xA6); // Set Normal Display (not inverse)

    oled_write_cmd(0x2E); // Deactivate scrolling

    // 3. 清空屏幕并开启显示
    oled_clear();
    oled_display_on();
}

/*
 * 功能：开启 OLED 显示
 */
void oled_display_on(void)
{
    oled_write_cmd(0xAF);
}

/*
 * 功能：关闭 OLED 显示
 */
void oled_display_off(void)
{
    oled_write_cmd(0xAE);
}
/*
 * 功能：设置 OLED 的坐标 (使用 Page Addressing Mode)
 * @param x: 横坐标 (0~127)
 * @param y: 纵坐标 (0~63) -- 实际上会被转换为页地址
 */
void oled_set_pos(uint8_t x, uint8_t y)
{
    oled_write_cmd(0xB0 + y);             // 设置页地址
    oled_write_cmd(((x & 0xF0) >> 4) | 0x10); // 设置高位列地址
    oled_write_cmd((x & 0x0F) | 0x00);    // 设置低位列地址
}

/*
 * 功能：将整个 RAM 填充为指定数据 (0x00全灭，0xFF全亮)
 * @param data: 填充的数据
 */
void oled_full_ram(uint8_t data)
{
    uint8_t i, j;
    for (i = 0; i < 8; i++) { // 8 pages
        oled_write_cmd(0xB0 + i);
        oled_write_cmd(0x00);
        oled_write_cmd(0x10);
        for (j = 0; j < 128; j++) {
            oled_write_data(data);
        }
    }
}

/*
 * 功能：清空整个屏幕 (即全写0)
 */
void oled_clear(void)
{
    oled_full_ram(0x00);
}

/*
 * 功能：在指定位置显示一个 ASCII 字符
 * @param x: 横坐标 (列)
 * @param y: 纵坐标 (行)，这里是第几行，不是Y坐标，代码内部会转换为页
 * @param chr: 要显示的字符
 */
void oled_show_char(uint8_t x, uint8_t y, uint8_t chr)
{
    // ASCII 字符表从空格 (0x20) 开始，计算字库中的索引
    uint8_t c = chr - ' ';
    if (x > OLED_WIDTH - 1) { x = 0; y++; }

    // 检查是否是换行符
    if (chr == '\n') {
        return;
    }

    oled_set_pos(x, y);
    for (uint8_t i = 0; i < 6; i++) {
        oled_write_data(F6x8[c][i]); // F6x8 是定义在 oledfont.h 中的字库
    }
}

/*
 * 功能：在指定位置显示一串 ASCII 字符串
 * @param x, y: 起始位置
 * @param str: 要显示的字符串
 */
void oled_show_string(uint8_t x, uint8_t y, const char *str)
{
    while (*str) {
        oled_show_char(x, y, *str);
        x += 6;          // 因为使用的是 6x8 字体，所以列坐标加 6
        if (x > OLED_WIDTH - 6) // 如果超出屏幕宽度，则换行
        {
            x = 0;
            y += 1;
            if (y > 7) { // 屏幕只有8页，超出则返回
                 y = 0;
            }
        }
        str++;
    }
}

/* 查找 16x16 中文字模 */
static const uint8_t *oled_find_hz16(uint32_t unicode)
{
    for (uint32_t i = 0; i < HZ16_COUNT; i++)
    {
        if (HZ16[i].unicode == unicode)
        {
            return HZ16[i].data;
        }
    }
    return RT_NULL;
}

/* 解析一个 UTF-8 字符，返回下一个字符指针 */
static const char *oled_utf8_next(const char *s, uint32_t *unicode)
{
    const uint8_t *p = (const uint8_t *)s;

    if (p[0] < 0x80)
    {
        *unicode = p[0];
        return s + 1;
    }
    else if ((p[0] & 0xE0) == 0xC0)
    {
        *unicode = ((uint32_t)(p[0] & 0x1F) << 6) |
                   ((uint32_t)(p[1] & 0x3F));
        return s + 2;
    }
    else if ((p[0] & 0xF0) == 0xE0)
    {
        *unicode = ((uint32_t)(p[0] & 0x0F) << 12) |
                   ((uint32_t)(p[1] & 0x3F) << 6) |
                   ((uint32_t)(p[2] & 0x3F));
        return s + 3;
    }
    else
    {
        *unicode = '?';
        return s + 1;
    }
}

/* 清除一行 16 像素高的显示区域 */
void oled_clear_line16(uint8_t y_page)
{
    if (y_page > 6)
    {
        return;
    }

    for (uint8_t page = y_page; page < y_page + 2; page++)
    {
        oled_set_pos(0, page);
        for (uint8_t x = 0; x < OLED_WIDTH; x++)
        {
            oled_write_data(0x00);
        }
    }
}

/* 显示一个 16x16 中文字符 */
void oled_show_hz16_char(uint8_t x, uint8_t y_page, uint32_t unicode)
{
    if (x > OLED_WIDTH - 16 || y_page > 6)
    {
        return;
    }

    const uint8_t *data = oled_find_hz16(unicode);
    if (data == RT_NULL)
    {
        /* 字库里没有这个汉字，就显示 ? */
        oled_show_char(x, y_page + 1, '?');
        return;
    }

    oled_set_pos(x, y_page);
    for (uint8_t i = 0; i < 16; i++)
    {
        oled_write_data(data[i]);
    }

    oled_set_pos(x, y_page + 1);
    for (uint8_t i = 0; i < 16; i++)
    {
        oled_write_data(data[i + 16]);
    }
}

/* 显示 UTF-8 字符串：中文 16x16，ASCII 使用原来的 6x8 */
void oled_show_utf8_string(uint8_t x, uint8_t y_page, const char *str)
{
    uint32_t unicode;

    while (*str && x < OLED_WIDTH)
    {
        str = oled_utf8_next(str, &unicode);

        if (unicode < 0x80)
        {
            if (x > OLED_WIDTH - 6)
            {
                break;
            }

            /* ASCII 仍用原来的 6x8 字库，放在 16 像素行的下半页 */
            oled_show_char(x, y_page + 1, (uint8_t)unicode);
            x += 6;
        }
        else
        {
            if (x > OLED_WIDTH - 16)
            {
                break;
            }

            oled_show_hz16_char(x, y_page, unicode);
            x += 16;
        }
    }
}

