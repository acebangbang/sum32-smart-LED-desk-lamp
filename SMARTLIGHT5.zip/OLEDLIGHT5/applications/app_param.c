#include "app_param.h"
#include "app_config.h"
#include <stddef.h>

/*
 * STM32F407VET6 内部 Flash 参数保存模块
 *
 * 设计目标：
 * 1. 上电自动恢复模式、手动亮度、色温。
 * 2. 不每次都擦除 Flash，而是在一个 Flash sector 内顺序追加记录。
 * 3. 记录带 magic/version/crc/commit，写入时最后写 commit，降低掉电写坏数据的风险。
 * 4. sector 写满后才整 sector 擦除，减少擦写次数。
 *
 * 默认使用 app_config.h 中配置的：
 * APP_PARAM_FLASH_ADDR   0x08060000
 * APP_PARAM_FLASH_SECTOR FLASH_SECTOR_7
 * APP_PARAM_FLASH_SIZE   128KB
 *
 * 如果你的程序代码已经超过 0x08060000，请务必调整保存扇区或链接脚本。
 */

#define APP_PARAM_MAGIC         0x504D4153UL  /* 'SAMP' little-endian，Smart-lAMP params */
#define APP_PARAM_VERSION       0x00010000UL
#define APP_PARAM_COMMIT_MARK   0xA55A5AA5UL
#define APP_PARAM_EMPTY_WORD    0xFFFFFFFFUL

#ifndef APP_PARAM_FLASH_VOLTAGE_RANGE
#define APP_PARAM_FLASH_VOLTAGE_RANGE FLASH_VOLTAGE_RANGE_3
#endif

typedef struct
{
    uint32_t magic;
    uint32_t version;
    uint32_t sequence;
    uint32_t mode;
    int32_t  manual_brightness;
    int32_t  manual_cct;
    uint32_t crc32;
    uint32_t commit;
} app_param_flash_record_t;

#define APP_PARAM_RECORD_SIZE   ((uint32_t)sizeof(app_param_flash_record_t))
#define APP_PARAM_SLOT_COUNT    ((uint32_t)(APP_PARAM_FLASH_SIZE / APP_PARAM_RECORD_SIZE))

static uint32_t crc32_update(uint32_t crc, const uint8_t *data, uint32_t len)
{
    while (len--)
    {
        crc ^= *data++;
        for (uint8_t i = 0; i < 8; i++)
        {
            if (crc & 1U)
            {
                crc = (crc >> 1) ^ 0xEDB88320UL;
            }
            else
            {
                crc >>= 1;
            }
        }
    }

    return crc;
}

static uint32_t record_crc32(const app_param_flash_record_t *record)
{
    uint32_t crc = 0xFFFFFFFFUL;

    crc = crc32_update(crc,
                       (const uint8_t *)record,
                       (uint32_t)offsetof(app_param_flash_record_t, crc32));

    return crc ^ 0xFFFFFFFFUL;
}

static const app_param_flash_record_t *slot_record(uint32_t slot)
{
    return (const app_param_flash_record_t *)(APP_PARAM_FLASH_ADDR + slot * APP_PARAM_RECORD_SIZE);
}

static rt_bool_t slot_is_erased(const app_param_flash_record_t *record)
{
    const uint32_t *word = (const uint32_t *)record;

    for (uint32_t i = 0; i < APP_PARAM_RECORD_SIZE / 4U; i++)
    {
        if (word[i] != APP_PARAM_EMPTY_WORD)
        {
            return RT_FALSE;
        }
    }

    return RT_TRUE;
}

void app_param_set_default(app_param_t *param)
{
    if (param == RT_NULL)
    {
        return;
    }

    param->mode = APP_PARAM_DEFAULT_MODE;
    param->manual_brightness = APP_PARAM_DEFAULT_BRIGHTNESS;
    param->manual_cct = CCT_DEFAULT_K;
}

void app_param_sanitize(app_param_t *param)
{
    if (param == RT_NULL)
    {
        return;
    }

    if (param->mode < 0 || param->mode > APP_PARAM_MODE_MAX)
    {
        param->mode = APP_PARAM_DEFAULT_MODE;
    }

    if (param->manual_brightness < 0)
    {
        param->manual_brightness = 0;
    }
    else if (param->manual_brightness > 100)
    {
        param->manual_brightness = 100;
    }

    if (param->manual_cct < CCT_WARM_K)
    {
        param->manual_cct = CCT_WARM_K;
    }
    else if (param->manual_cct > CCT_COOL_K)
    {
        param->manual_cct = CCT_COOL_K;
    }
}

rt_bool_t app_param_equal(const app_param_t *a, const app_param_t *b)
{
    if (a == RT_NULL || b == RT_NULL)
    {
        return RT_FALSE;
    }

    return (a->mode == b->mode &&
            a->manual_brightness == b->manual_brightness &&
            a->manual_cct == b->manual_cct) ? RT_TRUE : RT_FALSE;
}

static rt_bool_t record_to_param(const app_param_flash_record_t *record, app_param_t *param)
{
    app_param_t tmp;

    if (record == RT_NULL || param == RT_NULL)
    {
        return RT_FALSE;
    }

    if (record->magic != APP_PARAM_MAGIC ||
        record->version != APP_PARAM_VERSION ||
        record->commit != APP_PARAM_COMMIT_MARK)
    {
        return RT_FALSE;
    }

    if (record->crc32 != record_crc32(record))
    {
        return RT_FALSE;
    }

    tmp.mode = (int)record->mode;
    tmp.manual_brightness = (int)record->manual_brightness;
    tmp.manual_cct = (int)record->manual_cct;

    app_param_sanitize(&tmp);

    if (tmp.mode != (int)record->mode ||
        tmp.manual_brightness != (int)record->manual_brightness ||
        tmp.manual_cct != (int)record->manual_cct)
    {
        return RT_FALSE;
    }

    *param = tmp;
    return RT_TRUE;
}

static rt_bool_t find_latest_record(uint32_t *slot_out, uint32_t *sequence_out, app_param_t *param_out)
{
    rt_bool_t found = RT_FALSE;
    uint32_t best_slot = 0;
    uint32_t best_sequence = 0;
    app_param_t best_param;

    for (uint32_t i = 0; i < APP_PARAM_SLOT_COUNT; i++)
    {
        const app_param_flash_record_t *record = slot_record(i);
        app_param_t param;

        if (record_to_param(record, &param) == RT_TRUE)
        {
            if (found == RT_FALSE || record->sequence >= best_sequence)
            {
                found = RT_TRUE;
                best_slot = i;
                best_sequence = record->sequence;
                best_param = param;
            }
        }
    }

    if (found == RT_TRUE)
    {
        if (slot_out != RT_NULL)
        {
            *slot_out = best_slot;
        }
        if (sequence_out != RT_NULL)
        {
            *sequence_out = best_sequence;
        }
        if (param_out != RT_NULL)
        {
            *param_out = best_param;
        }
    }

    return found;
}

static rt_bool_t find_empty_slot(uint32_t *slot_out)
{
    for (uint32_t i = 0; i < APP_PARAM_SLOT_COUNT; i++)
    {
        if (slot_is_erased(slot_record(i)) == RT_TRUE)
        {
            if (slot_out != RT_NULL)
            {
                *slot_out = i;
            }
            return RT_TRUE;
        }
    }

    return RT_FALSE;
}

static int erase_param_sector(void)
{
    HAL_StatusTypeDef status;
    FLASH_EraseInitTypeDef erase = {0};
    uint32_t sector_error = 0;

    status = HAL_FLASH_Unlock();
    if (status != HAL_OK)
    {
        return -RT_ERROR;
    }

    erase.TypeErase = FLASH_TYPEERASE_SECTORS;
    erase.Sector = APP_PARAM_FLASH_SECTOR;
    erase.NbSectors = 1;
    erase.VoltageRange = APP_PARAM_FLASH_VOLTAGE_RANGE;

    status = HAL_FLASHEx_Erase(&erase, &sector_error);
    HAL_FLASH_Lock();

    if (status != HAL_OK || sector_error != 0xFFFFFFFFUL)
    {
        rt_kprintf("app_param: erase flash sector failed, status=%d, sector_error=0x%08x\r\n",
                   status, sector_error);
        return -RT_ERROR;
    }

    return RT_EOK;
}

static int program_word(uint32_t address, uint32_t data)
{
    if (HAL_FLASH_Program(FLASH_TYPEPROGRAM_WORD, address, (uint64_t)data) != HAL_OK)
    {
        return -RT_ERROR;
    }

    if (*(volatile uint32_t *)address != data)
    {
        return -RT_ERROR;
    }

    return RT_EOK;
}

static int write_record(uint32_t slot, const app_param_t *param, uint32_t sequence)
{
    app_param_flash_record_t record;
    uint32_t address;
    const uint32_t *word;
    int result = RT_EOK;

    if (param == RT_NULL || slot >= APP_PARAM_SLOT_COUNT)
    {
        return -RT_ERROR;
    }

    record.magic = APP_PARAM_MAGIC;
    record.version = APP_PARAM_VERSION;
    record.sequence = sequence;
    record.mode = (uint32_t)param->mode;
    record.manual_brightness = (int32_t)param->manual_brightness;
    record.manual_cct = (int32_t)param->manual_cct;
    record.crc32 = record_crc32(&record);
    record.commit = APP_PARAM_EMPTY_WORD;

    word = (const uint32_t *)&record;
    address = APP_PARAM_FLASH_ADDR + slot * APP_PARAM_RECORD_SIZE;

    if (HAL_FLASH_Unlock() != HAL_OK)
    {
        return -RT_ERROR;
    }

    /* 先写 commit 之前的所有字段。 */
    for (uint32_t i = 0; i < (APP_PARAM_RECORD_SIZE / 4U) - 1U; i++)
    {
        if (program_word(address + i * 4U, word[i]) != RT_EOK)
        {
            result = -RT_ERROR;
            break;
        }
    }

    /* 最后写 commit 标记。掉电时如果 commit 没写入，则该记录无效。 */
    if (result == RT_EOK)
    {
        if (program_word(address + APP_PARAM_RECORD_SIZE - 4U, APP_PARAM_COMMIT_MARK) != RT_EOK)
        {
            result = -RT_ERROR;
        }
    }

    HAL_FLASH_Lock();

    if (result != RT_EOK)
    {
        rt_kprintf("app_param: write flash record failed at slot %d\r\n", slot);
        return -RT_ERROR;
    }

    return RT_EOK;
}

int app_param_init(void)
{
    if ((APP_PARAM_FLASH_ADDR % 4U) != 0U || APP_PARAM_SLOT_COUNT == 0U)
    {
        rt_kprintf("app_param: invalid flash config\r\n");
        return -RT_ERROR;
    }

    rt_kprintf("app_param: flash addr=0x%08x, sector=%d, slots=%d\r\n",
               APP_PARAM_FLASH_ADDR,
               APP_PARAM_FLASH_SECTOR,
               APP_PARAM_SLOT_COUNT);

    return RT_EOK;
}

int app_param_load(app_param_t *param)
{
    app_param_t loaded;
    uint32_t slot;
    uint32_t sequence;

    if (param == RT_NULL)
    {
        return -RT_ERROR;
    }

    if (find_latest_record(&slot, &sequence, &loaded) == RT_TRUE)
    {
        *param = loaded;
        rt_kprintf("app_param: loaded slot=%d seq=%u mode=%d bri=%d cct=%d\r\n",
                   slot, sequence, param->mode, param->manual_brightness, param->manual_cct);
        return RT_EOK;
    }

    app_param_set_default(param);
    rt_kprintf("app_param: no valid record, use default\r\n");
    return -RT_ERROR;
}

int app_param_save(const app_param_t *param)
{
    app_param_t new_param;
    app_param_t old_param;
    uint32_t latest_slot = 0;
    uint32_t latest_sequence = 0;
    uint32_t empty_slot = 0;
    uint32_t next_sequence = 0;

    if (param == RT_NULL)
    {
        return -RT_ERROR;
    }

    new_param = *param;
    app_param_sanitize(&new_param);

    if (find_latest_record(&latest_slot, &latest_sequence, &old_param) == RT_TRUE)
    {
        if (app_param_equal(&old_param, &new_param) == RT_TRUE)
        {
            return RT_EOK;
        }
        next_sequence = latest_sequence + 1U;
    }
    else
    {
        next_sequence = 0U;
    }

    if (find_empty_slot(&empty_slot) != RT_TRUE)
    {
        if (erase_param_sector() != RT_EOK)
        {
            return -RT_ERROR;
        }
        empty_slot = 0U;
    }

    if (write_record(empty_slot, &new_param, next_sequence) != RT_EOK)
    {
        return -RT_ERROR;
    }

    rt_kprintf("app_param: saved slot=%d seq=%u mode=%d bri=%d cct=%d\r\n",
               empty_slot, next_sequence,
               new_param.mode, new_param.manual_brightness, new_param.manual_cct);

    return RT_EOK;
}
