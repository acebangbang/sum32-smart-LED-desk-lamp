#ifndef __APP_ENCODER_H__
#define __APP_ENCODER_H__

#include <rtthread.h>

int encoder_init(void);
int encoder_get_delta(void);

#endif
