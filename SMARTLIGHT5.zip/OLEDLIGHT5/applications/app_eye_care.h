#ifndef __APP_EYE_CARE_H__
#define __APP_EYE_CARE_H__

#include <rtthread.h>
#include "app_config.h"

#ifndef EYE_CARE_FILTER_COUNT
#define EYE_CARE_FILTER_COUNT 5
#endif

typedef enum
{
    EYE_CARE_NORMAL = 0,
    EYE_CARE_TOO_DARK,
    EYE_CARE_TOO_BRIGHT
} eye_care_state_t;

typedef enum
{
    EYE_POPUP_NONE = 0,
    EYE_POPUP_DARK,
    EYE_POPUP_BRIGHT,
    EYE_POPUP_AUTO_BRIGHTEN,
    EYE_POPUP_AUTO_DIM
} eye_care_popup_t;

typedef struct
{
    rt_bool_t enabled;
    rt_bool_t avg_valid;
    float avg_lux;
    eye_care_state_t state;
    eye_care_popup_t popup;
    rt_bool_t popup_active;
    rt_bool_t blink_active;
    int blink_offset;
    int auto_brightness;
    rt_bool_t auto_adjusted;
} eye_care_result_t;

typedef struct
{
    rt_bool_t enabled;

    float samples[EYE_CARE_FILTER_COUNT];
    int sample_count;
    int sample_index;
    rt_tick_t last_sample_tick;

    eye_care_state_t state;
    eye_care_state_t candidate_state;
    rt_tick_t candidate_since_tick;
    rt_tick_t abnormal_since_tick;

    eye_care_popup_t popup;
    rt_tick_t popup_start_tick;
    rt_bool_t pending_popup;
    eye_care_popup_t pending_popup_type;

    rt_tick_t blink_start_tick;
    rt_tick_t last_blink_trigger_tick;

    int auto_brightness;
    rt_tick_t last_auto_tick;
    rt_bool_t auto_popup_sent;

    eye_care_result_t result;
} eye_care_ctrl_t;

void eye_care_init(eye_care_ctrl_t *ctx, int initial_brightness);
void eye_care_set_enable(eye_care_ctrl_t *ctx, rt_bool_t enable);
rt_bool_t eye_care_is_enable(const eye_care_ctrl_t *ctx);
void eye_care_set_auto_brightness(eye_care_ctrl_t *ctx, int brightness);
int eye_care_get_auto_brightness(const eye_care_ctrl_t *ctx);
void eye_care_clear_popup(eye_care_ctrl_t *ctx);
void eye_care_process(eye_care_ctrl_t *ctx,
                      rt_bool_t lux_ok,
                      float lux,
                      rt_bool_t auto_mode,
                      rt_bool_t lamp_power,
                      rt_bool_t allow_popup);
const eye_care_result_t *eye_care_get_result(const eye_care_ctrl_t *ctx);

#endif /* __APP_EYE_CARE_H__ */
