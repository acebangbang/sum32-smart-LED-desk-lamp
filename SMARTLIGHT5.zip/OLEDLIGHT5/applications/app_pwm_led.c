#include "app_pwm_led.h"
#include "app_config.h"

TIM_HandleTypeDef htim2;

static int g_led_percent = 0;
static int g_cct_kelvin = CCT_DEFAULT_K;
static int g_warm_percent = 0;
static int g_cool_percent = 0;

static int clamp_int(int value, int min, int max)
{
    if (value < min) return min;
    if (value > max) return max;
    return value;
}

static uint32_t get_apb1_timer_clock(void)
{
    uint32_t pclk1 = HAL_RCC_GetPCLK1Freq();
    uint32_t ppre1 = RCC->CFGR & RCC_CFGR_PPRE1;

    if (ppre1 == RCC_HCLK_DIV1)
    {
        return pclk1;
    }
    return pclk1 * 2U;
}

static void pwm_gpio_init(void)
{
    GPIO_InitTypeDef GPIO_InitStruct = {0};

    __HAL_RCC_GPIOA_CLK_ENABLE();
    __HAL_RCC_TIM2_CLK_ENABLE();

    /* PA2 -> TIM2_CH3 暖白 WW，PA3 -> TIM2_CH4 冷白 CW，AF1 */
    GPIO_InitStruct.Pin       = GPIO_PIN_2 | GPIO_PIN_3;
    GPIO_InitStruct.Mode      = GPIO_MODE_AF_PP;
    GPIO_InitStruct.Pull      = GPIO_NOPULL;
    GPIO_InitStruct.Speed     = GPIO_SPEED_FREQ_LOW;
    GPIO_InitStruct.Alternate = GPIO_AF1_TIM2;
    HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);
}

static void pwm_set_channel_counts(uint32_t channel, uint32_t counts)
{
    if (counts > PWM_PERIOD_COUNTS)
    {
        counts = PWM_PERIOD_COUNTS;
    }

#if LED_ACTIVE_HIGH
    __HAL_TIM_SET_COMPARE(&htim2, channel, counts);
#else
    __HAL_TIM_SET_COMPARE(&htim2, channel, PWM_PERIOD_COUNTS - counts);
#endif
}

int pwm_led_init(void)
{
    TIM_OC_InitTypeDef sConfigOC = {0};

    pwm_gpio_init();

    uint32_t tim_clk = get_apb1_timer_clock();
    uint32_t prescaler = (tim_clk / PWM_TIMER_TICK_HZ) - 1U;

    htim2.Instance = TIM2;
    htim2.Init.Prescaler = prescaler;
    htim2.Init.CounterMode = TIM_COUNTERMODE_UP;
    htim2.Init.Period = PWM_PERIOD_COUNTS - 1U;
    htim2.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
    htim2.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;

    if (HAL_TIM_PWM_Init(&htim2) != HAL_OK)
    {
        rt_kprintf("TIM2 PWM init failed\r\n");
        return -RT_ERROR;
    }

    sConfigOC.OCMode = TIM_OCMODE_PWM1;
    sConfigOC.Pulse = 0;
    sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
    sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;

    if (HAL_TIM_PWM_ConfigChannel(&htim2, &sConfigOC, TIM_CHANNEL_3) != HAL_OK)
    {
        rt_kprintf("TIM2 CH3 PWM config failed\r\n");
        return -RT_ERROR;
    }

    if (HAL_TIM_PWM_ConfigChannel(&htim2, &sConfigOC, TIM_CHANNEL_4) != HAL_OK)
    {
        rt_kprintf("TIM2 CH4 PWM config failed\r\n");
        return -RT_ERROR;
    }

    if (HAL_TIM_PWM_Start(&htim2, TIM_CHANNEL_3) != HAL_OK)
    {
        rt_kprintf("TIM2 CH3 PWM start failed\r\n");
        return -RT_ERROR;
    }

    if (HAL_TIM_PWM_Start(&htim2, TIM_CHANNEL_4) != HAL_OK)
    {
        rt_kprintf("TIM2 CH4 PWM start failed\r\n");
        return -RT_ERROR;
    }

    pwm_led_set_percent_cct(0, CCT_DEFAULT_K);
    rt_kprintf("Dual CCT PWM LED ready: PA2 TIM2_CH3 WW, PA3 TIM2_CH4 CW, %d Hz\r\n", PWM_FREQ_HZ);
    return RT_EOK;
}

void pwm_led_set_percent_cct(int percent, int cct_kelvin)
{
    uint32_t total_counts;
    uint32_t warm_counts;
    uint32_t cool_counts;

    percent = clamp_int(percent, 0, 100);
    cct_kelvin = clamp_int(cct_kelvin, CCT_WARM_K, CCT_COOL_K);

    total_counts = PWM_PERIOD_COUNTS * (uint32_t)percent / 100U;

    /*
     * 3000K: warm=100%, cool=0%
     * 6500K: warm=0%,   cool=100%
     */
    cool_counts = total_counts * (uint32_t)(cct_kelvin - CCT_WARM_K) /
                  (uint32_t)(CCT_COOL_K - CCT_WARM_K);
    warm_counts = total_counts - cool_counts;

    pwm_set_channel_counts(TIM_CHANNEL_3, warm_counts); /* PA2 -> WW */
    pwm_set_channel_counts(TIM_CHANNEL_4, cool_counts); /* PA3 -> CW */

    g_led_percent = percent;
    g_cct_kelvin = cct_kelvin;
    g_warm_percent = (int)(warm_counts * 100U / PWM_PERIOD_COUNTS);
    g_cool_percent = (int)(cool_counts * 100U / PWM_PERIOD_COUNTS);
}

void pwm_led_set_percent(int percent)
{
    pwm_led_set_percent_cct(percent, g_cct_kelvin);
}

void pwm_led_set_color_temp(int cct_kelvin)
{
    pwm_led_set_percent_cct(g_led_percent, cct_kelvin);
}

int pwm_led_get_percent(void)
{
    return g_led_percent;
}

int pwm_led_get_cct(void)
{
    return g_cct_kelvin;
}

int pwm_led_get_warm_percent(void)
{
    return g_warm_percent;
}

int pwm_led_get_cool_percent(void)
{
    return g_cool_percent;
}

int pwm_led_percent_from_lux(float lux)
{
    int percent;

    if (lux <= AUTO_DARK_LUX)
    {
        percent = AUTO_MAX_BRIGHTNESS;
    }
    else if (lux >= AUTO_BRIGHT_LUX)
    {
        percent = AUTO_MIN_BRIGHTNESS;
    }
    else
    {
        float ratio = (AUTO_BRIGHT_LUX - lux) / (AUTO_BRIGHT_LUX - AUTO_DARK_LUX);
        percent = AUTO_MIN_BRIGHTNESS + (int)((AUTO_MAX_BRIGHTNESS - AUTO_MIN_BRIGHTNESS) * ratio + 0.5f);
    }

    if (percent < AUTO_MIN_BRIGHTNESS) percent = AUTO_MIN_BRIGHTNESS;
    if (percent > AUTO_MAX_BRIGHTNESS) percent = AUTO_MAX_BRIGHTNESS;
    return percent;
}
