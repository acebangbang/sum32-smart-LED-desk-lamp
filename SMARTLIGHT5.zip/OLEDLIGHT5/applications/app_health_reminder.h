#ifndef __APP_HEALTH_REMINDER_H__
#define __APP_HEALTH_REMINDER_H__

#include <rtthread.h>
#include "app_config.h"

typedef struct
{
    rt_bool_t enabled;
    rt_bool_t popup_active;
    rt_bool_t pending;
    rt_uint32_t elapsed_sec;
} health_reminder_result_t;

typedef struct
{
    rt_bool_t enabled;
    rt_bool_t lamp_running;
    rt_tick_t start_tick;
    rt_tick_t next_remind_tick;
    rt_tick_t popup_start_tick;
    rt_bool_t pending;
    health_reminder_result_t result;
} health_reminder_ctrl_t;

void health_reminder_init(health_reminder_ctrl_t *ctx);
void health_reminder_process(health_reminder_ctrl_t *ctx,
                             rt_bool_t lamp_power,
                             rt_bool_t allow_popup);
void health_reminder_dismiss(health_reminder_ctrl_t *ctx);
const health_reminder_result_t *health_reminder_get_result(const health_reminder_ctrl_t *ctx);

#endif /* __APP_HEALTH_REMINDER_H__ */
