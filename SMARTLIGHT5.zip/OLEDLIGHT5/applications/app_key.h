#ifndef __APP_KEY_H__
#define __APP_KEY_H__

#include <rtthread.h>

typedef enum
{
    APP_KEY_EVENT_NONE = 0,
    APP_KEY_EVENT_SHORT,
    APP_KEY_EVENT_LONG
} app_key_event_t;

void key_init(void);

/* 扫描 PB0 按键事件：短按用于原菜单确认，长按用于开灯/关灯 */
app_key_event_t key_mode_scan(void);

/* 兼容旧接口：只把短按事件作为 pressed 返回 */
int key_mode_pressed(void);

#endif
