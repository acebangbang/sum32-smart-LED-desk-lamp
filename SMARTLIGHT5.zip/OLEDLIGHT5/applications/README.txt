OLED 菜单版 + 60 秒自动息屏

替换文件：
- app_config.h
- main.c
- oled.c
- oled.h
- oledfont.h

功能：
1. OLED 60 秒无按键/编码器操作后自动熄屏。
2. 按键或旋转编码器后 OLED 自动唤醒。
3. OLED 中文菜单：旋转编码器上下选择，PB0 确认。
4. 菜单项：自动模式、亮度调节、色温调节、返回主页。
5. 亮度调节页：旋转编码器调整亮度，PB0 确认返回主页。
6. 色温调节页：旋转编码器调整色温，PB0 确认返回主页。
7. 保留 app_param 掉电保存逻辑。

注意：
- oledfont.h 已补充菜单相关汉字：菜单、选择、确认、返回、主页、调节、值、旋钮、调整等。
- 如果编码器方向相反，修改 main.c 中 menu_index + delta、manual_brightness += delta、manual_cct += delta 的符号即可。

- 启动画面中的参数读取提示也已改为中文：参数正常 / 参数默认。


菜单稳定性修正：
- 编码器原始增量会被限幅为 -1/0/+1。
- 默认 120ms 内只响应一次菜单/编辑步进。
- 菜单上下选择时不再整屏 oled_clear()，只更新变化行。


编码器修正：
- app_encoder.c 不再直接返回 TIM3 原始计数差值。
- 新增 g_encoder_accum 累计原始计数。
- 每 ENCODER_COUNTS_PER_STEP 个原始计数才返回 1 步。
- 默认 ENCODER_COUNTS_PER_STEP = 4。
- 如果一格仍跳多项，把 ENCODER_COUNTS_PER_STEP 改成 6 或 8。
- 如果一格经常没反应，把 ENCODER_COUNTS_PER_STEP 改成 2。
