#ifndef __APP_CONFIG_H__
#define __APP_CONFIG_H__

#include <rtthread.h>
#include <rtdevice.h>
#include "board.h"

/* ====================== 硬件连接配置 ======================
 * MCU: STM32F407VET6
 *
 * OLED SSD1306/SSD1315: I2C3
 *   PA8  -> I2C3_SCL
 *   PC9  -> I2C3_SDA
 *
 * BH1750: I2C1
 *   PB6  -> I2C1_SCL
 *   PB7  -> I2C1_SDA
 *   ADDR -> GND: 地址 0x23；ADDR -> VCC: 地址 0x5C
 *
 * 双色温三线灯带 DC12V:
 *   +12V -> 灯带公共正极
 *   WW   -> 暖白 MOSFET 低端开关，PA2 TIM2_CH3 输出 PWM
 *   CW   -> 冷白 MOSFET 低端开关，PA3 TIM2_CH4 输出 PWM
 *
 * 旋转编码器:
 *   PA6  -> TIM3_CH1
 *   PA7  -> TIM3_CH2
 *
 * 模式切换按键:
 *   PB0  -> GPIO_Input, Pull-up, 按下接 GND
 * ========================================================= */

#define APP_KEY_MODE_PIN        GET_PIN(B, 0)

/* 默认 PB0 按下为低电平 */
#define APP_KEY_ACTIVE_LEVEL    PIN_LOW
#define APP_KEY_DEBOUNCE_MS     40
#define APP_KEY_LONG_PRESS_MS   1000

/* MOSFET 低端驱动：PWM 高电平 -> MOSFET 导通 -> 灯带点亮 */
#define LED_ACTIVE_HIGH         1

/* PWM: 1 kHz，计数基准 1 MHz，Period = 1000 - 1，占空比 0~100% */
#define PWM_FREQ_HZ             1000U
#define PWM_TIMER_TICK_HZ       1000000U
#define PWM_PERIOD_COUNTS       (PWM_TIMER_TICK_HZ / PWM_FREQ_HZ)

/* 编码器参数 */
#define ENCODER_FILTER          8

/* TIM 编码器原始计数折算：常见机械编码器一格约 4 个计数。
 * 如果一格仍跳多项，可改大；如果一格不灵敏，可改小到 2。
 */
#define ENCODER_COUNTS_PER_STEP 4

#define BRIGHTNESS_STEP_PERCENT 5

/* 色温参数：2835 双色温灯带 3000K~6500K */
#define CCT_WARM_K              3000
#define CCT_COOL_K              6500
#define CCT_DEFAULT_K           4000
#define CCT_STEP_K              250

/* 自动调光阈值，可按实际环境修改
 * lux <= AUTO_DARK_LUX    -> 亮度 100%
 * lux >= AUTO_BRIGHT_LUX  -> 亮度 0%
 * 中间区域线性变化
 */
#define AUTO_DARK_LUX           10.0f
#define AUTO_BRIGHT_LUX         200.0f

/* 自动模式下亮度限幅，避免完全看不见或过亮；需要完全灭灯可把 MIN 设为 0 */
#define AUTO_MIN_BRIGHTNESS     2
#define AUTO_MAX_BRIGHTNESS     100





/* ====================== 用眼健康提醒配置 ======================
 * 测试阶段：台灯连续开启 20 秒提醒一次。
 * 正式使用时可改成 45U * 60U * 1000U。
 */
#define HEALTH_REMINDER_ENABLE          1
#define HEALTH_REMINDER_INTERVAL_MS     20000
#define HEALTH_REMINDER_POPUP_MS        8000

/* 提醒弹窗显示保护：用户最后一次按键/旋钮操作后，等待 2 秒再允许弹窗。 */
#define REMINDER_IDLE_GUARD_MS       2000

/* ====================== 护眼提醒配置 ======================
 * BH1750 已安装在可检测桌面照度的位置：
 *   阅读照度标准区间：300~700 lux
 *   自动模式目标照度：约 500 lux
 */
#define EYE_CARE_DEFAULT_ENABLE     1

/* 迟滞判断：避免 lux 在边界附近波动时反复弹窗 */
#define EYE_LUX_DARK_ENTER          280.0f
#define EYE_LUX_DARK_EXIT           330.0f
#define EYE_LUX_BRIGHT_ENTER        750.0f
#define EYE_LUX_BRIGHT_EXIT         680.0f

/* 自动模式闭环调光目标 */
#define EYE_TARGET_LUX              500.0f
#define EYE_TARGET_DEADBAND         40.0f
#define EYE_AUTO_CONTROL_MS         400
#define EYE_AUTO_STEP_PERCENT       6
#define EYE_AUTO_POPUP_DELAY_MS     10000
#define EYE_AUTO_POPUP_ENABLE       0       /* 0=自动微调只串口提示，不打断 OLED 当前页面 */

/* 采样滤波和提醒参数 */
#define EYE_CARE_FILTER_COUNT       5
#define EYE_SAMPLE_INTERVAL_MS      500
#define EYE_CONFIRM_MS              3000
#define EYE_POPUP_MS                5000
#define EYE_BLINK_OFFSET_PERCENT    5
#define EYE_BLINK_PERIOD_MS         800
#define EYE_BLINK_DURATION_MS       3000
#define EYE_BLINK_COOLDOWN_MS       30000

/* ====================== 掉电参数保存配置 ======================
 * STM32F407VET6 常见 Flash: 512KB，地址 0x08000000 ~ 0x0807FFFF。
 * 这里默认使用最后一个 128KB Sector 7 保存参数。
 *
 * 重要：如果你的程序编译后已经占用到 0x08060000 之后，不能直接使用这个地址，
 *      需要修改链接脚本/Flash 分区，或者把参数保存地址改到未使用的 sector。
 */
#define APP_PARAM_DEFAULT_MODE          0       /* 0=自动，1=手动亮度，2=手动色温 */
#define APP_PARAM_MODE_MAX              2
#define APP_PARAM_DEFAULT_BRIGHTNESS    30

#define APP_PARAM_SAVE_DELAY_MS         1500    /* 旋钮停止约 1.5 秒后再保存，减少 Flash 写入 */

#define APP_PARAM_FLASH_ADDR            ((uint32_t)0x08060000U)
#define APP_PARAM_FLASH_SECTOR          FLASH_SECTOR_7
#define APP_PARAM_FLASH_SIZE            (128U * 1024U)
#define APP_PARAM_FLASH_VOLTAGE_RANGE   FLASH_VOLTAGE_RANGE_3

#define OLED_REFRESH_MS         500

/* OLED 自动息屏：用户确认本项目先保持 15 秒关闭显示 */
#define OLED_SLEEP_TIMEOUT_MS   15000

/* 菜单/编辑界面编码器限速，避免一格跳多项和 OLED 重绘抖动 */
#define UI_ENCODER_STEP_INTERVAL_MS 60
#define CONTROL_LOOP_MS         100

#endif
