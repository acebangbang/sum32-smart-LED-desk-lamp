#ifndef __APP_PWM_LED_H__
#define __APP_PWM_LED_H__

#include <rtthread.h>

int pwm_led_init(void);

/* 兼容原来的单亮度接口：只改总亮度，色温保持不变 */
void pwm_led_set_percent(int percent);
int pwm_led_get_percent(void);
int pwm_led_percent_from_lux(float lux);

/* 新增双色温接口 */
void pwm_led_set_percent_cct(int percent, int cct_kelvin);
void pwm_led_set_color_temp(int cct_kelvin);
int pwm_led_get_cct(void);
int pwm_led_get_warm_percent(void);
int pwm_led_get_cool_percent(void);

#endif
