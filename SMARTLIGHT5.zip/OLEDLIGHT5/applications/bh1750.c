#include "bh1750.h"

#define DBG_TAG "bh1750"
#define DBG_LVL DBG_LOG
#include <rtdbg.h>

static struct rt_i2c_bus_device *g_i2c_bus = RT_NULL;

static rt_err_t bh1750_send_cmd(bh1750_cmd_t cmd)
{
    struct rt_i2c_msg msg;
    rt_uint8_t data = (rt_uint8_t)cmd;

    if (g_i2c_bus == RT_NULL)
    {
        return -RT_ERROR;
    }

    msg.addr  = BH1750_ADDR;
    msg.flags = RT_I2C_WR;
    msg.buf   = &data;
    msg.len   = 1;

    return (rt_i2c_transfer(g_i2c_bus, &msg, 1) == 1) ? RT_EOK : -RT_ERROR;
}

int bh1750_init(void)
{
    g_i2c_bus = (struct rt_i2c_bus_device *)rt_device_find(BH1750_I2C_BUS_NAME);
    if (g_i2c_bus == RT_NULL)
    {
        LOG_E("I2C bus %s not found", BH1750_I2C_BUS_NAME);
        return -RT_ERROR;
    }

    if (bh1750_send_cmd(BH1750_POWER_ON) != RT_EOK)
    {
        LOG_E("BH1750 power on failed");
        return -RT_ERROR;
    }
    rt_thread_mdelay(10);

    if (bh1750_send_cmd(BH1750_RESET) != RT_EOK)
    {
        LOG_W("BH1750 reset failed, continue anyway");
    }
    rt_thread_mdelay(10);

    if (bh1750_send_cmd(BH1750_CONT_H_MODE) != RT_EOK)
    {
        LOG_E("BH1750 set continuous high resolution mode failed");
        return -RT_ERROR;
    }

    /* 高分辨率连续测量首次转换约 120ms，这里留足时间 */
    rt_thread_mdelay(180);
    LOG_I("BH1750 ready on %s, addr=0x%02X", BH1750_I2C_BUS_NAME, BH1750_ADDR);
    return RT_EOK;
}

rt_err_t bh1750_read_lux(float *lux)
{
    struct rt_i2c_msg msg;
    rt_uint8_t data[2] = {0};

    if (lux == RT_NULL || g_i2c_bus == RT_NULL)
    {
        return -RT_ERROR;
    }

    msg.addr  = BH1750_ADDR;
    msg.flags = RT_I2C_RD;
    msg.buf   = data;
    msg.len   = 2;

    if (rt_i2c_transfer(g_i2c_bus, &msg, 1) != 1)
    {
        return -RT_ERROR;
    }

    rt_uint16_t raw = ((rt_uint16_t)data[0] << 8) | data[1];
    *lux = (float)raw / 1.2f;
    return RT_EOK;
}
