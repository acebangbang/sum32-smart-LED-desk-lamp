#include "app_eye_care.h"

#ifndef EYE_CARE_DEFAULT_ENABLE
#define EYE_CARE_DEFAULT_ENABLE     1
#endif

#ifndef EYE_LUX_DARK_ENTER
#define EYE_LUX_DARK_ENTER          280.0f
#endif

#ifndef EYE_LUX_DARK_EXIT
#define EYE_LUX_DARK_EXIT           330.0f
#endif

#ifndef EYE_LUX_BRIGHT_ENTER
#define EYE_LUX_BRIGHT_ENTER        750.0f
#endif

#ifndef EYE_LUX_BRIGHT_EXIT
#define EYE_LUX_BRIGHT_EXIT         680.0f
#endif

#ifndef EYE_TARGET_LUX
#define EYE_TARGET_LUX              500.0f
#endif

#ifndef EYE_TARGET_DEADBAND
#define EYE_TARGET_DEADBAND         60.0f
#endif

#ifndef EYE_SAMPLE_INTERVAL_MS
#define EYE_SAMPLE_INTERVAL_MS      500
#endif

#ifndef EYE_CONFIRM_MS
#define EYE_CONFIRM_MS              3000
#endif

#ifndef EYE_POPUP_MS
#define EYE_POPUP_MS                5000
#endif

#ifndef EYE_BLINK_OFFSET_PERCENT
#define EYE_BLINK_OFFSET_PERCENT    5
#endif

#ifndef EYE_BLINK_PERIOD_MS
#define EYE_BLINK_PERIOD_MS         800
#endif

#ifndef EYE_BLINK_DURATION_MS
#define EYE_BLINK_DURATION_MS       3000
#endif

#ifndef EYE_BLINK_COOLDOWN_MS
#define EYE_BLINK_COOLDOWN_MS       30000
#endif

#ifndef EYE_AUTO_CONTROL_MS
#define EYE_AUTO_CONTROL_MS         2000
#endif

#ifndef EYE_AUTO_STEP_PERCENT
#define EYE_AUTO_STEP_PERCENT       2
#endif

#ifndef EYE_AUTO_POPUP_DELAY_MS
#define EYE_AUTO_POPUP_DELAY_MS     10000
#endif

#ifndef EYE_AUTO_POPUP_ENABLE
#define EYE_AUTO_POPUP_ENABLE       0
#endif

static int eye_clamp_int(int value, int min, int max)
{
    if (value < min) return min;
    if (value > max) return max;
    return value;
}

static eye_care_state_t eye_calc_state(eye_care_state_t current, float lux)
{
    if (current == EYE_CARE_TOO_DARK)
    {
        return (lux >= EYE_LUX_DARK_EXIT) ? EYE_CARE_NORMAL : EYE_CARE_TOO_DARK;
    }

    if (current == EYE_CARE_TOO_BRIGHT)
    {
        return (lux <= EYE_LUX_BRIGHT_EXIT) ? EYE_CARE_NORMAL : EYE_CARE_TOO_BRIGHT;
    }

    if (lux <= EYE_LUX_DARK_ENTER)
    {
        return EYE_CARE_TOO_DARK;
    }

    if (lux >= EYE_LUX_BRIGHT_ENTER)
    {
        return EYE_CARE_TOO_BRIGHT;
    }

    return EYE_CARE_NORMAL;
}

static float eye_average_lux(const eye_care_ctrl_t *ctx)
{
    float sum = 0.0f;

    if (ctx == RT_NULL || ctx->sample_count <= 0)
    {
        return 0.0f;
    }

    for (int i = 0; i < ctx->sample_count; i++)
    {
        sum += ctx->samples[i];
    }

    return sum / (float)ctx->sample_count;
}

static void eye_start_popup(eye_care_ctrl_t *ctx, eye_care_popup_t popup)
{
    if (ctx == RT_NULL)
    {
        return;
    }

    ctx->popup = popup;
    ctx->popup_start_tick = rt_tick_get();
}

static void eye_request_popup(eye_care_ctrl_t *ctx, eye_care_popup_t popup, rt_bool_t allow_popup)
{
    if (ctx == RT_NULL)
    {
        return;
    }

    if (allow_popup == RT_TRUE)
    {
        ctx->pending_popup = RT_FALSE;
        ctx->pending_popup_type = EYE_POPUP_NONE;
        eye_start_popup(ctx, popup);
    }
    else
    {
        ctx->pending_popup = RT_TRUE;
        ctx->pending_popup_type = popup;
        ctx->popup = EYE_POPUP_NONE;
        ctx->popup_start_tick = 0;
    }
}

static void eye_update_result(eye_care_ctrl_t *ctx)
{
    rt_tick_t now;
    rt_bool_t popup_active = RT_FALSE;
    rt_bool_t blink_active = RT_FALSE;
    int blink_offset = 0;

    if (ctx == RT_NULL)
    {
        return;
    }

    now = rt_tick_get();

    if (ctx->popup != EYE_POPUP_NONE)
    {
        if (now - ctx->popup_start_tick < rt_tick_from_millisecond(EYE_POPUP_MS))
        {
            popup_active = RT_TRUE;
        }
        else
        {
            ctx->popup = EYE_POPUP_NONE;
        }
    }

    if (ctx->blink_start_tick != 0)
    {
        rt_tick_t elapsed = now - ctx->blink_start_tick;
        if (elapsed < rt_tick_from_millisecond(EYE_BLINK_DURATION_MS))
        {
            rt_uint32_t elapsed_ms = elapsed * 1000U / RT_TICK_PER_SECOND;
            rt_uint32_t phase = elapsed_ms / (EYE_BLINK_PERIOD_MS / 2U);
            blink_active = RT_TRUE;
            blink_offset = (phase % 2U == 0U) ? -EYE_BLINK_OFFSET_PERCENT : EYE_BLINK_OFFSET_PERCENT;
        }
        else
        {
            ctx->blink_start_tick = 0;
        }
    }

    ctx->result.enabled = ctx->enabled;
    ctx->result.avg_valid = (ctx->sample_count > 0) ? RT_TRUE : RT_FALSE;
    ctx->result.avg_lux = eye_average_lux(ctx);
    ctx->result.state = ctx->state;
    ctx->result.popup = ctx->popup;
    ctx->result.popup_active = popup_active;
    ctx->result.blink_active = blink_active;
    ctx->result.blink_offset = blink_offset;
    ctx->result.auto_brightness = ctx->auto_brightness;
}

void eye_care_init(eye_care_ctrl_t *ctx, int initial_brightness)
{
    if (ctx == RT_NULL)
    {
        return;
    }

    rt_memset(ctx, 0, sizeof(*ctx));
    ctx->enabled = EYE_CARE_DEFAULT_ENABLE ? RT_TRUE : RT_FALSE;
    ctx->state = EYE_CARE_NORMAL;
    ctx->candidate_state = EYE_CARE_NORMAL;
    ctx->popup = EYE_POPUP_NONE;
    ctx->auto_brightness = eye_clamp_int(initial_brightness, AUTO_MIN_BRIGHTNESS, AUTO_MAX_BRIGHTNESS);
    ctx->result.auto_brightness = ctx->auto_brightness;
    ctx->result.enabled = ctx->enabled;
}

void eye_care_set_enable(eye_care_ctrl_t *ctx, rt_bool_t enable)
{
    if (ctx == RT_NULL)
    {
        return;
    }

    ctx->enabled = enable ? RT_TRUE : RT_FALSE;
    ctx->state = EYE_CARE_NORMAL;
    ctx->candidate_state = EYE_CARE_NORMAL;
    ctx->popup = EYE_POPUP_NONE;
    ctx->pending_popup = RT_FALSE;
    ctx->pending_popup_type = EYE_POPUP_NONE;
    ctx->blink_start_tick = 0;
    ctx->auto_popup_sent = RT_FALSE;
    eye_update_result(ctx);

    rt_kprintf("护眼提醒：%s\r\n", ctx->enabled ? "开启" : "关闭");
}

rt_bool_t eye_care_is_enable(const eye_care_ctrl_t *ctx)
{
    if (ctx == RT_NULL)
    {
        return RT_FALSE;
    }

    return ctx->enabled;
}

void eye_care_set_auto_brightness(eye_care_ctrl_t *ctx, int brightness)
{
    if (ctx == RT_NULL)
    {
        return;
    }

    ctx->auto_brightness = eye_clamp_int(brightness, AUTO_MIN_BRIGHTNESS, AUTO_MAX_BRIGHTNESS);
    ctx->result.auto_brightness = ctx->auto_brightness;
}

int eye_care_get_auto_brightness(const eye_care_ctrl_t *ctx)
{
    if (ctx == RT_NULL)
    {
        return 0;
    }

    return ctx->auto_brightness;
}

void eye_care_clear_popup(eye_care_ctrl_t *ctx)
{
    if (ctx == RT_NULL)
    {
        return;
    }

    ctx->popup = EYE_POPUP_NONE;
    ctx->popup_start_tick = 0;
    ctx->pending_popup = RT_FALSE;
    ctx->pending_popup_type = EYE_POPUP_NONE;
    ctx->blink_start_tick = 0;
    eye_update_result(ctx);
}

void eye_care_process(eye_care_ctrl_t *ctx,
                      rt_bool_t lux_ok,
                      float lux,
                      rt_bool_t auto_mode,
                      rt_bool_t lamp_power,
                      rt_bool_t allow_popup)
{
    rt_tick_t now;
    rt_bool_t sampled = RT_FALSE;
    float avg_lux;
    eye_care_state_t target_state;

    if (ctx == RT_NULL)
    {
        return;
    }

    ctx->result.auto_adjusted = RT_FALSE;
    now = rt_tick_get();

    if (lux_ok == RT_TRUE)
    {
        if (ctx->last_sample_tick == 0 ||
            now - ctx->last_sample_tick >= rt_tick_from_millisecond(EYE_SAMPLE_INTERVAL_MS))
        {
            ctx->last_sample_tick = now;
            ctx->samples[ctx->sample_index] = lux;
            ctx->sample_index++;
            if (ctx->sample_index >= EYE_CARE_FILTER_COUNT)
            {
                ctx->sample_index = 0;
            }
            if (ctx->sample_count < EYE_CARE_FILTER_COUNT)
            {
                ctx->sample_count++;
            }
            sampled = RT_TRUE;
        }
    }

    if (ctx->enabled == RT_FALSE || lux_ok == RT_FALSE || ctx->sample_count <= 0 || lamp_power == RT_FALSE)
    {
        ctx->state = EYE_CARE_NORMAL;
        ctx->candidate_state = EYE_CARE_NORMAL;
        ctx->popup = EYE_POPUP_NONE;
        ctx->pending_popup = RT_FALSE;
        ctx->pending_popup_type = EYE_POPUP_NONE;
        ctx->blink_start_tick = 0;
        eye_update_result(ctx);
        return;
    }

    avg_lux = eye_average_lux(ctx);

    if (auto_mode == RT_TRUE && sampled == RT_TRUE)
    {
        if (ctx->last_auto_tick == 0 ||
            now - ctx->last_auto_tick >= rt_tick_from_millisecond(EYE_AUTO_CONTROL_MS))
        {
            int old_brightness = ctx->auto_brightness;

            ctx->last_auto_tick = now;

            if (avg_lux < (EYE_TARGET_LUX - EYE_TARGET_DEADBAND))
            {
                ctx->auto_brightness += EYE_AUTO_STEP_PERCENT;
            }
            else if (avg_lux > (EYE_TARGET_LUX + EYE_TARGET_DEADBAND))
            {
                ctx->auto_brightness -= EYE_AUTO_STEP_PERCENT;
            }

            ctx->auto_brightness = eye_clamp_int(ctx->auto_brightness, AUTO_MIN_BRIGHTNESS, AUTO_MAX_BRIGHTNESS);
            if (ctx->auto_brightness != old_brightness)
            {
                ctx->result.auto_adjusted = RT_TRUE;
            }
        }
    }

    target_state = eye_calc_state(ctx->state, avg_lux);

    if (target_state == EYE_CARE_NORMAL)
    {
        if (ctx->state != EYE_CARE_NORMAL)
        {
            rt_kprintf("护眼提醒：光照恢复正常，当前 %d lux\r\n", (int)(avg_lux + 0.5f));
        }
        ctx->state = EYE_CARE_NORMAL;
        ctx->candidate_state = EYE_CARE_NORMAL;
        ctx->abnormal_since_tick = 0;
        ctx->auto_popup_sent = RT_FALSE;
        ctx->popup = EYE_POPUP_NONE;
        ctx->pending_popup = RT_FALSE;
        ctx->pending_popup_type = EYE_POPUP_NONE;
        ctx->blink_start_tick = 0;
        eye_update_result(ctx);
        return;
    }

    if (ctx->state != target_state)
    {
        if (ctx->candidate_state != target_state)
        {
            ctx->candidate_state = target_state;
            ctx->candidate_since_tick = now;
        }

        if (now - ctx->candidate_since_tick >= rt_tick_from_millisecond(EYE_CONFIRM_MS))
        {
            ctx->state = target_state;
            ctx->abnormal_since_tick = now;
            ctx->auto_popup_sent = RT_FALSE;

            if (ctx->state == EYE_CARE_TOO_DARK)
            {
                eye_request_popup(ctx, EYE_POPUP_DARK, allow_popup);
                rt_kprintf("护眼提醒：光照偏暗，当前 %d lux\r\n", (int)(avg_lux + 0.5f));
            }
            else
            {
                eye_request_popup(ctx, EYE_POPUP_BRIGHT, allow_popup);
                rt_kprintf("护眼提醒：光照偏亮，当前 %d lux\r\n", (int)(avg_lux + 0.5f));
            }

            if (ctx->last_blink_trigger_tick == 0 ||
                now - ctx->last_blink_trigger_tick >= rt_tick_from_millisecond(EYE_BLINK_COOLDOWN_MS))
            {
                ctx->blink_start_tick = now;
                ctx->last_blink_trigger_tick = now;
            }
        }
    }
    else
    {
        ctx->candidate_state = target_state;
    }

    if (ctx->pending_popup == RT_TRUE && allow_popup == RT_TRUE && ctx->state != EYE_CARE_NORMAL)
    {
        eye_start_popup(ctx, ctx->pending_popup_type);
        ctx->pending_popup = RT_FALSE;
        ctx->pending_popup_type = EYE_POPUP_NONE;
    }

    if (auto_mode == RT_TRUE && ctx->state != EYE_CARE_NORMAL && ctx->abnormal_since_tick != 0)
    {
        if (ctx->auto_popup_sent == RT_FALSE &&
            now - ctx->abnormal_since_tick >= rt_tick_from_millisecond(EYE_AUTO_POPUP_DELAY_MS))
        {
            ctx->auto_popup_sent = RT_TRUE;
            if (ctx->state == EYE_CARE_TOO_DARK)
            {
#if EYE_AUTO_POPUP_ENABLE
                eye_request_popup(ctx, EYE_POPUP_AUTO_BRIGHTEN, allow_popup);
#endif
                rt_kprintf("自动调节：光照偏暗，已自动调亮，亮度 %d%%\r\n", ctx->auto_brightness);
            }
            else
            {
#if EYE_AUTO_POPUP_ENABLE
                eye_request_popup(ctx, EYE_POPUP_AUTO_DIM, allow_popup);
#endif
                rt_kprintf("自动调节：光照偏亮，已自动调暗，亮度 %d%%\r\n", ctx->auto_brightness);
            }
        }
    }

    eye_update_result(ctx);
}

const eye_care_result_t *eye_care_get_result(const eye_care_ctrl_t *ctx)
{
    if (ctx == RT_NULL)
    {
        return RT_NULL;
    }

    return &ctx->result;
}
