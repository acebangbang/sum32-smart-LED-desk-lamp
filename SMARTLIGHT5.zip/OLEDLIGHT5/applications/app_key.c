#include "app_key.h"
#include "app_config.h"

#if APP_KEY_ACTIVE_LEVEL == PIN_LOW
#define APP_KEY_RELEASE_LEVEL   PIN_HIGH
#else
#define APP_KEY_RELEASE_LEVEL   PIN_LOW
#endif

void key_init(void)
{
#if APP_KEY_ACTIVE_LEVEL == PIN_LOW
    rt_pin_mode(APP_KEY_MODE_PIN, PIN_MODE_INPUT_PULLUP);
#else
    rt_pin_mode(APP_KEY_MODE_PIN, PIN_MODE_INPUT_PULLDOWN);
#endif
}

app_key_event_t key_mode_scan(void)
{
    static rt_uint8_t last_raw = APP_KEY_RELEASE_LEVEL;
    static rt_uint8_t stable_level = APP_KEY_RELEASE_LEVEL;
    static rt_tick_t last_change_tick = 0;
    static rt_tick_t press_tick = 0;
    static rt_bool_t long_sent = RT_FALSE;

    rt_uint8_t raw = rt_pin_read(APP_KEY_MODE_PIN);
    rt_tick_t now = rt_tick_get();

    /* 原始电平变化，重新开始消抖计时 */
    if (raw != last_raw)
    {
        last_raw = raw;
        last_change_tick = now;
        return APP_KEY_EVENT_NONE;
    }

    /* 消抖时间未到 */
    if (now - last_change_tick < rt_tick_from_millisecond(APP_KEY_DEBOUNCE_MS))
    {
        return APP_KEY_EVENT_NONE;
    }

    /* 稳定电平发生变化 */
    if (raw != stable_level)
    {
        stable_level = raw;

        /* 稳定按下 */
        if (stable_level == APP_KEY_ACTIVE_LEVEL)
        {
            press_tick = now;
            long_sent = RT_FALSE;
        }
        /* 稳定松开 */
        else
        {
            if (long_sent == RT_FALSE)
            {
                return APP_KEY_EVENT_SHORT;
            }

            long_sent = RT_FALSE;
        }

        return APP_KEY_EVENT_NONE;
    }

    /* 按住不放，判断长按。长按只触发一次，松开后不会再触发短按。 */
    if (stable_level == APP_KEY_ACTIVE_LEVEL)
    {
        if (long_sent == RT_FALSE)
        {
            if (now - press_tick >= rt_tick_from_millisecond(APP_KEY_LONG_PRESS_MS))
            {
                long_sent = RT_TRUE;
                return APP_KEY_EVENT_LONG;
            }
        }
    }

    return APP_KEY_EVENT_NONE;
}

int key_mode_pressed(void)
{
    return (key_mode_scan() == APP_KEY_EVENT_SHORT) ? 1 : 0;
}
