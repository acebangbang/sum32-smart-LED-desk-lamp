#include "app_health_reminder.h"

#ifndef HEALTH_REMINDER_ENABLE
#define HEALTH_REMINDER_ENABLE          1
#endif

#ifndef HEALTH_REMINDER_INTERVAL_MS
#define HEALTH_REMINDER_INTERVAL_MS     20000
#endif

#ifndef HEALTH_REMINDER_POPUP_MS
#define HEALTH_REMINDER_POPUP_MS        8000
#endif

static rt_uint32_t health_elapsed_sec(rt_tick_t start_tick, rt_tick_t now)
{
    if (start_tick == 0)
    {
        return 0U;
    }

    return (rt_uint32_t)((now - start_tick) / RT_TICK_PER_SECOND);
}

static void health_update_result(health_reminder_ctrl_t *ctx)
{
    rt_tick_t now;

    if (ctx == RT_NULL)
    {
        return;
    }

    now = rt_tick_get();
    ctx->result.enabled = ctx->enabled;
    ctx->result.popup_active = RT_FALSE;
    ctx->result.pending = ctx->pending;
    ctx->result.elapsed_sec = ctx->lamp_running ? health_elapsed_sec(ctx->start_tick, now) : 0U;

    if (ctx->popup_start_tick != 0)
    {
        if (now - ctx->popup_start_tick < rt_tick_from_millisecond(HEALTH_REMINDER_POPUP_MS))
        {
            ctx->result.popup_active = RT_TRUE;
        }
        else
        {
            ctx->popup_start_tick = 0;
        }
    }
}

void health_reminder_init(health_reminder_ctrl_t *ctx)
{
    if (ctx == RT_NULL)
    {
        return;
    }

    rt_memset(ctx, 0, sizeof(*ctx));
    ctx->enabled = HEALTH_REMINDER_ENABLE ? RT_TRUE : RT_FALSE;
    health_update_result(ctx);
}

void health_reminder_process(health_reminder_ctrl_t *ctx,
                             rt_bool_t lamp_power,
                             rt_bool_t allow_popup)
{
    rt_tick_t now;

    if (ctx == RT_NULL)
    {
        return;
    }

    now = rt_tick_get();

    if (ctx->enabled == RT_FALSE)
    {
        ctx->lamp_running = RT_FALSE;
        ctx->start_tick = 0;
        ctx->next_remind_tick = 0;
        ctx->popup_start_tick = 0;
        ctx->pending = RT_FALSE;
        health_update_result(ctx);
        return;
    }

    if (lamp_power == RT_FALSE)
    {
        if (ctx->lamp_running == RT_TRUE)
        {
            rt_kprintf("用眼提醒：台灯已关闭，连续计时清零\r\n");
        }
        ctx->lamp_running = RT_FALSE;
        ctx->start_tick = 0;
        ctx->next_remind_tick = 0;
        ctx->popup_start_tick = 0;
        ctx->pending = RT_FALSE;
        health_update_result(ctx);
        return;
    }

    if (ctx->lamp_running == RT_FALSE)
    {
        ctx->lamp_running = RT_TRUE;
        ctx->start_tick = now;
        ctx->next_remind_tick = now + rt_tick_from_millisecond(HEALTH_REMINDER_INTERVAL_MS);
        ctx->popup_start_tick = 0;
        ctx->pending = RT_FALSE;
        rt_kprintf("用眼提醒：开始连续开启计时\r\n");
    }

    if (ctx->pending == RT_TRUE)
    {
        if (allow_popup == RT_TRUE)
        {
            ctx->popup_start_tick = now;
            ctx->pending = RT_FALSE;
            ctx->next_remind_tick = now + rt_tick_from_millisecond(HEALTH_REMINDER_INTERVAL_MS);
            rt_kprintf("用眼提醒：显示休息提醒，已连续开启 %lu 秒\r\n",
                       (unsigned long)health_elapsed_sec(ctx->start_tick, now));
        }
        health_update_result(ctx);
        return;
    }

    if (ctx->next_remind_tick != 0 &&
        now - ctx->next_remind_tick < (rt_tick_t)(0x7FFFFFFFU))
    {
        if (allow_popup == RT_TRUE)
        {
            ctx->popup_start_tick = now;
            ctx->next_remind_tick = now + rt_tick_from_millisecond(HEALTH_REMINDER_INTERVAL_MS);
            rt_kprintf("用眼提醒：显示休息提醒，已连续开启 %lu 秒\r\n",
                       (unsigned long)health_elapsed_sec(ctx->start_tick, now));
        }
        else
        {
            ctx->pending = RT_TRUE;
            rt_kprintf("用眼提醒：已到提醒时间，等待返回主页显示\r\n");
        }
    }

    health_update_result(ctx);
}

void health_reminder_dismiss(health_reminder_ctrl_t *ctx)
{
    if (ctx == RT_NULL)
    {
        return;
    }

    ctx->popup_start_tick = 0;
    ctx->pending = RT_FALSE;
    health_update_result(ctx);
    rt_kprintf("用眼提醒：用户关闭弹窗\r\n");
}

const health_reminder_result_t *health_reminder_get_result(const health_reminder_ctrl_t *ctx)
{
    if (ctx == RT_NULL)
    {
        return RT_NULL;
    }

    return &ctx->result;
}
