#include <rtthread.h>
#include <rtdevice.h>
#include "app_config.h"
#include "oled.h"
#include "bh1750.h"
#include "app_pwm_led.h"
#include "app_encoder.h"
#include "app_key.h"
#include "app_param.h"
#include "app_eye_care.h"
#include "app_health_reminder.h"

#ifndef OLED_SLEEP_TIMEOUT_MS
#define OLED_SLEEP_TIMEOUT_MS   60000
#endif

#ifndef UI_ENCODER_STEP_INTERVAL_MS
#define UI_ENCODER_STEP_INTERVAL_MS 120
#endif

#ifndef TIMER_OFF_STEP_MS
#define TIMER_OFF_STEP_MS       1000
#endif

#ifndef REMINDER_IDLE_GUARD_MS
#define REMINDER_IDLE_GUARD_MS  2000
#endif

typedef enum
{
    MODE_AUTO = 0,
    MODE_MANUAL_BRI,
    MODE_MANUAL_CCT
} app_mode_t;

typedef enum
{
    UI_HOME = 0,
    UI_MENU,
    UI_EDIT_BRI,
    UI_EDIT_CCT,
    UI_TIMER_SET,
    UI_EYE_CARE_SET
} ui_page_t;

typedef enum
{
    MENU_AUTO = 0,
    MENU_BRI,
    MENU_CCT,
    MENU_TIMER,
    MENU_EYE_CARE,
    MENU_BACK,
    MENU_COUNT
} menu_item_t;

typedef enum
{
    APP_TIMER_OFF = 0,
    APP_TIMER_10S,
    APP_TIMER_30MIN,
    APP_TIMER_60MIN,
    APP_TIMER_120MIN,
    APP_TIMER_COUNT
} app_timer_item_t;

/* OLED 防闪烁缓存。OLED 熄屏或切换页面后会清屏，所以缓存必须能被重置。 */
static char g_oled_last_text[4][48] = {{0}};
static uint16_t g_oled_last_width[4] = {0};
static rt_bool_t g_oled_last_has_cn[4] = {RT_FALSE};

static int clamp_int(int value, int min, int max)
{
    if (value < min) return min;
    if (value > max) return max;
    return value;
}

static int wrap_index(int value, int count)
{
    if (count <= 0) return 0;
    while (value < 0) value += count;
    while (value >= count) value -= count;
    return value;
}

static rt_bool_t ui_reminder_allowed(ui_page_t ui_page, rt_tick_t last_input_tick)
{
    if (ui_page != UI_HOME)
    {
        return RT_FALSE;
    }

    if (rt_tick_get() - last_input_tick < rt_tick_from_millisecond(REMINDER_IDLE_GUARD_MS))
    {
        return RT_FALSE;
    }

    return RT_TRUE;
}



/*
 * 编码器菜单步进滤波：
 * 1. 把任意正/负增量限幅为 +1/-1，避免一格跳多项。
 * 2. 做一个最小时间间隔，避免编码器抖动或一格多脉冲导致菜单乱跳。
 */
static int encoder_delta_to_ui_step(int raw_delta, rt_tick_t *last_step_tick)
{
    int step;
    rt_tick_t now;

    if (raw_delta > 0)
    {
        step = 1;
    }
    else if (raw_delta < 0)
    {
        step = -1;
    }
    else
    {
        return 0;
    }

    if (last_step_tick == RT_NULL)
    {
        return step;
    }

    now = rt_tick_get();
    if (now - *last_step_tick < rt_tick_from_millisecond(UI_ENCODER_STEP_INTERVAL_MS))
    {
        return 0;
    }

    *last_step_tick = now;
    return step;
}

static const char *mode_text(app_mode_t mode)
{
    switch (mode)
    {
    case MODE_AUTO:       return "自动";
    case MODE_MANUAL_BRI: return "手动亮度";
    case MODE_MANUAL_CCT: return "手动色温";
    default:              return "未知";
    }
}

static const char *menu_text(menu_item_t item)
{
    switch (item)
    {
    case MENU_AUTO:  return "自动模式";
    case MENU_BRI:   return "亮度调节";
    case MENU_CCT:   return "色温调节";
    case MENU_TIMER:    return "定时开关";
    case MENU_EYE_CARE: return "光照开关";
    case MENU_BACK:     return "返回主页";
    default:        return "未知";
    }
}


static const char *timer_text(app_timer_item_t item)
{
    switch (item)
    {
    case APP_TIMER_OFF:    return "关闭";
    case APP_TIMER_10S:    return "10秒";
    case APP_TIMER_30MIN:  return "30分钟";
    case APP_TIMER_60MIN:  return "60分钟";
    case APP_TIMER_120MIN: return "120分钟";
    default:               return "?";
    }
}

static rt_uint32_t timer_seconds(app_timer_item_t item)
{
    switch (item)
    {
    case APP_TIMER_10S:    return 10U;
    case APP_TIMER_30MIN:  return 30U * 60U;
    case APP_TIMER_60MIN:  return 60U * 60U;
    case APP_TIMER_120MIN: return 120U * 60U;
    case APP_TIMER_OFF:
    default:               return 0U;
    }
}

static int list_first_index(int selected, int count, int visible_count)
{
    int first;

    if (count <= visible_count)
    {
        return 0;
    }

    first = selected - visible_count / 2;
    if (first < 0)
    {
        first = 0;
    }
    if (first > count - visible_count)
    {
        first = count - visible_count;
    }

    return first;
}

static void timer_format_remaining(char *buf, int size, rt_uint32_t sec)
{
    rt_uint32_t hour = sec / 3600U;
    rt_uint32_t min = (sec % 3600U) / 60U;
    rt_uint32_t second = sec % 60U;

    if (buf == RT_NULL || size <= 0)
    {
        return;
    }

    if (hour > 0U)
    {
        rt_snprintf(buf, size, "定时%02lu:%02lu:%02lu",
                    (unsigned long)hour,
                    (unsigned long)min,
                    (unsigned long)second);
    }
    else
    {
        rt_snprintf(buf, size, "定时%02lu:%02lu",
                    (unsigned long)min,
                    (unsigned long)second);
    }
}

static void timer_off_start(app_timer_item_t item,
                            rt_bool_t *timer_active,
                            rt_uint32_t *timer_remaining_sec,
                            rt_tick_t *last_timer_tick)
{
    rt_uint32_t seconds;

    if (timer_active == RT_NULL || timer_remaining_sec == RT_NULL || last_timer_tick == RT_NULL)
    {
        return;
    }

    seconds = timer_seconds(item);
    if (seconds == 0U)
    {
        *timer_active = RT_FALSE;
        *timer_remaining_sec = 0U;
        *last_timer_tick = 0;
        return;
    }

    *timer_active = RT_TRUE;
    *timer_remaining_sec = seconds;
    *last_timer_tick = rt_tick_get();
}

static void timer_off_cancel(rt_bool_t *timer_active,
                             rt_uint32_t *timer_remaining_sec,
                             rt_tick_t *last_timer_tick)
{
    if (timer_active == RT_NULL || timer_remaining_sec == RT_NULL || last_timer_tick == RT_NULL)
    {
        return;
    }

    *timer_active = RT_FALSE;
    *timer_remaining_sec = 0U;
    *last_timer_tick = 0;
}

/* 返回 RT_TRUE 表示定时到，需要关灯。 */
static rt_bool_t timer_off_process(rt_bool_t *timer_active,
                                   rt_uint32_t *timer_remaining_sec,
                                   rt_tick_t *last_timer_tick)
{
    rt_tick_t now;
    rt_tick_t step_tick;

    if (timer_active == RT_NULL || timer_remaining_sec == RT_NULL || last_timer_tick == RT_NULL)
    {
        return RT_FALSE;
    }

    if (*timer_active == RT_FALSE)
    {
        return RT_FALSE;
    }

    if (*timer_remaining_sec == 0U)
    {
        *timer_active = RT_FALSE;
        *last_timer_tick = 0;
        return RT_TRUE;
    }

    now = rt_tick_get();
    step_tick = rt_tick_from_millisecond(TIMER_OFF_STEP_MS);

    while ((now - *last_timer_tick) >= step_tick)
    {
        *last_timer_tick += step_tick;

        if (*timer_remaining_sec > 0U)
        {
            (*timer_remaining_sec)--;
        }

        if (*timer_remaining_sec == 0U)
        {
            *timer_active = RT_FALSE;
            *last_timer_tick = 0;
            return RT_TRUE;
        }
    }

    return RT_FALSE;
}

/* 为了避免中文残影，这里环境状态固定为 1 个汉字 */
static const char *env_text(float lux)
{
    if (lux <= AUTO_DARK_LUX) return "暗";
    if (lux >= AUTO_BRIGHT_LUX) return "亮";
    return "正常";   /* 正 = 正常 */
}

static const char *oled_utf8_step_for_width(const char *s, rt_bool_t *is_cn)
{
    const unsigned char *p = (const unsigned char *)s;

    if (is_cn != RT_NULL)
    {
        *is_cn = RT_FALSE;
    }

    if (p[0] < 0x80)
    {
        return s + 1;
    }
    else if ((p[0] & 0xE0) == 0xC0)
    {
        if (is_cn != RT_NULL) *is_cn = RT_TRUE;
        return s + 2;
    }
    else if ((p[0] & 0xF0) == 0xE0)
    {
        if (is_cn != RT_NULL) *is_cn = RT_TRUE;
        return s + 3;
    }

    return s + 1;
}

static uint16_t oled_text_width_px(const char *text, rt_bool_t *has_cn)
{
    uint16_t width = 0;
    rt_bool_t any_cn = RT_FALSE;

    if (text == RT_NULL)
    {
        if (has_cn != RT_NULL) *has_cn = RT_FALSE;
        return 0;
    }

    while (*text)
    {
        rt_bool_t is_cn = RT_FALSE;
        const char *next = oled_utf8_step_for_width(text, &is_cn);

        if (is_cn == RT_TRUE)
        {
            width += 16;
            any_cn = RT_TRUE;
        }
        else
        {
            width += 6;
        }

        text = next;
    }

    if (has_cn != RT_NULL)
    {
        *has_cn = any_cn;
    }

    return width;
}

static void oled_screen_cache_reset(void)
{
    rt_memset(g_oled_last_text, 0, sizeof(g_oled_last_text));
    rt_memset(g_oled_last_width, 0, sizeof(g_oled_last_width));
    rt_memset(g_oled_last_has_cn, 0, sizeof(g_oled_last_has_cn));
}

static void ui_force_redraw(rt_tick_t *last_oled_tick)
{
    oled_clear();
    oled_screen_cache_reset();
    if (last_oled_tick != RT_NULL)
    {
        *last_oled_tick = 0;
    }
}

static void oled_wake_up(rt_bool_t *oled_awake,
                         rt_tick_t *last_input_tick,
                         rt_tick_t *last_oled_tick)
{
    if (oled_awake == RT_NULL || last_input_tick == RT_NULL || last_oled_tick == RT_NULL)
    {
        return;
    }

    *last_input_tick = rt_tick_get();

    if (*oled_awake == RT_FALSE)
    {
        oled_display_on();
        ui_force_redraw(last_oled_tick);
        *oled_awake = RT_TRUE;
    }
}

static void oled_check_sleep(rt_bool_t *oled_awake, rt_tick_t last_input_tick)
{
    if (oled_awake == RT_NULL)
    {
        return;
    }

    if (*oled_awake == RT_TRUE)
    {
        if (rt_tick_get() - last_input_tick >= rt_tick_from_millisecond(OLED_SLEEP_TIMEOUT_MS))
        {
            oled_display_off();
            *oled_awake = RT_FALSE;
        }
    }
}

static void oled_update_line_cn(uint8_t row, const char *text, rt_bool_t need_clear)
{
    uint8_t page;
    uint16_t new_width;
    rt_bool_t new_has_cn;
    rt_bool_t clear_line = RT_FALSE;

    if (row > 3 || text == RT_NULL)
    {
        return;
    }

    if (rt_strncmp(g_oled_last_text[row], text, sizeof(g_oled_last_text[row])) == 0)
    {
        return;
    }

    page = row * 2;
    new_width = oled_text_width_px(text, &new_has_cn);

    /*
     * 防闪烁策略：
     * 1. 数字变化、同宽文字变化时不清整行，直接覆盖，避免 OLED 一闪一闪。
     * 2. 新内容更短时才清整行，避免旧字符残留。
     * 3. 从“有中文”切到“纯 ASCII”时清整行，避免上半页残留。
     * 4. need_clear 只在确实有旧内容时作为兜底，页面切换时 ui_force_redraw 已经清屏。
     */
    if (g_oled_last_width[row] > new_width)
    {
        clear_line = RT_TRUE;
    }
    else if (g_oled_last_has_cn[row] == RT_TRUE && new_has_cn == RT_FALSE)
    {
        clear_line = RT_TRUE;
    }
    else if (need_clear == RT_TRUE && g_oled_last_text[row][0] != '\0' &&
             (g_oled_last_width[row] != new_width))
    {
        clear_line = RT_TRUE;
    }

    if (clear_line == RT_TRUE)
    {
        oled_clear_line16(page);
    }

    oled_show_utf8_string(0, page, text);

    rt_strncpy(g_oled_last_text[row], text, sizeof(g_oled_last_text[row]) - 1);
    g_oled_last_text[row][sizeof(g_oled_last_text[row]) - 1] = '\0';
    g_oled_last_width[row] = new_width;
    g_oled_last_has_cn[row] = new_has_cn;
}

static void app_show_home_screen(app_mode_t mode,
                                 float lux,
                                 rt_bool_t lux_ok,
                                 rt_bool_t timer_active,
                                 rt_uint32_t timer_remaining_sec)
{
    char buf[48];

    rt_snprintf(buf, sizeof(buf), "模式:%s", mode_text(mode));
    oled_update_line_cn(0, buf, RT_TRUE);

    rt_snprintf(buf, sizeof(buf), "亮%3d%%温%4dK", pwm_led_get_percent(), pwm_led_get_cct());
    oled_update_line_cn(1, buf, RT_FALSE);

    if (lux_ok)
    {
        int lux_i = (int)(lux + 0.5f);
        rt_snprintf(buf, sizeof(buf), "光%4dlx境%s", lux_i, env_text(lux));
        oled_update_line_cn(2, buf, RT_FALSE);
    }
    else
    {
        oled_update_line_cn(2, "光照失败", RT_TRUE);
    }

    if (timer_active == RT_TRUE)
    {
        timer_format_remaining(buf, sizeof(buf), timer_remaining_sec);
        oled_update_line_cn(3, buf, RT_TRUE);
    }
    else
    {
        rt_snprintf(buf, sizeof(buf), "暖%3d%%冷%3d%%", pwm_led_get_warm_percent(), pwm_led_get_cool_percent());
        oled_update_line_cn(3, buf, RT_FALSE);
    }
}

static void app_show_menu_screen(int menu_index)
{
    char buf[48];
    int first;

    oled_update_line_cn(0, "菜单选择", RT_TRUE);

    first = list_first_index(menu_index, MENU_COUNT, 3);

    for (int row = 1; row <= 3; row++)
    {
        int item = first + row - 1;
        rt_snprintf(buf, sizeof(buf), "%c%s", (item == menu_index) ? '>' : ' ', menu_text((menu_item_t)item));
        oled_update_line_cn((uint8_t)row, buf, RT_TRUE);
    }
}

static void app_show_timer_set_screen(int timer_index)
{
    char buf[48];
    int first;

    oled_update_line_cn(0, "定时开关", RT_TRUE);

    first = list_first_index(timer_index, APP_TIMER_COUNT, 3);

    for (int row = 1; row <= 3; row++)
    {
        int item = first + row - 1;
        rt_snprintf(buf, sizeof(buf), "%c%s",
                    (item == timer_index) ? '>' : ' ',
                    timer_text((app_timer_item_t)item));
        oled_update_line_cn((uint8_t)row, buf, RT_TRUE);
    }
}

static void app_show_bri_edit_screen(int manual_brightness)
{
    char buf[48];

    oled_update_line_cn(0, "亮度调节", RT_TRUE);
    rt_snprintf(buf, sizeof(buf), "值:%3d%%", manual_brightness);
    oled_update_line_cn(1, buf, RT_FALSE);
    oled_update_line_cn(2, "旋钮调整", RT_TRUE);
    oled_update_line_cn(3, "按键确认", RT_TRUE);
}

static void app_show_cct_edit_screen(int manual_cct)
{
    char buf[48];

    oled_update_line_cn(0, "色温调节", RT_TRUE);
    rt_snprintf(buf, sizeof(buf), "值:%4dK", manual_cct);
    oled_update_line_cn(1, buf, RT_FALSE);
    oled_update_line_cn(2, "旋钮调整", RT_TRUE);
    oled_update_line_cn(3, "按键确认", RT_TRUE);
}

static void app_show_eye_care_set_screen(rt_bool_t eye_enable)
{
    oled_update_line_cn(0, "光照开关", RT_TRUE);
    oled_update_line_cn(1, eye_enable ? "开关:开" : "开关:关", RT_TRUE);
    oled_update_line_cn(2, "旋钮调整", RT_TRUE);
    oled_update_line_cn(3, "按键确认", RT_TRUE);
}

static void app_show_eye_care_popup(const eye_care_result_t *eye_result)
{
    char buf[48];
    int lux_i = 0;

    if (eye_result == RT_NULL)
    {
        return;
    }

    if (eye_result->avg_valid == RT_TRUE)
    {
        lux_i = (int)(eye_result->avg_lux + 0.5f);
    }

    switch (eye_result->popup)
    {
    case EYE_POPUP_DARK:
        oled_update_line_cn(0, "光照调整", RT_TRUE);
        oled_update_line_cn(1, "光照暗", RT_TRUE);
        oled_update_line_cn(2, "调亮度", RT_TRUE);
        rt_snprintf(buf, sizeof(buf), "光%4dlx", lux_i);
        oled_update_line_cn(3, buf, RT_TRUE);
        break;

    case EYE_POPUP_BRIGHT:
        oled_update_line_cn(0, "光照调整", RT_TRUE);
        oled_update_line_cn(1, "光照亮", RT_TRUE);
        oled_update_line_cn(2, "调暗亮度", RT_TRUE);
        rt_snprintf(buf, sizeof(buf), "光%4dlx", lux_i);
        oled_update_line_cn(3, buf, RT_TRUE);
        break;

    case EYE_POPUP_AUTO_BRIGHTEN:
        oled_update_line_cn(0, "自动调节", RT_TRUE);
        oled_update_line_cn(1, "光照暗", RT_TRUE);
        oled_update_line_cn(2, "自动调亮", RT_TRUE);
        rt_snprintf(buf, sizeof(buf), "光%4dlx", lux_i);
        oled_update_line_cn(3, buf, RT_TRUE);
        break;

    case EYE_POPUP_AUTO_DIM:
        oled_update_line_cn(0, "自动调节", RT_TRUE);
        oled_update_line_cn(1, "光照亮", RT_TRUE);
        oled_update_line_cn(2, "自动调暗", RT_TRUE);
        rt_snprintf(buf, sizeof(buf), "光%4dlx", lux_i);
        oled_update_line_cn(3, buf, RT_TRUE);
        break;

    case EYE_POPUP_NONE:
    default:
        break;
    }
}

static void app_show_health_reminder_popup(const health_reminder_result_t *health_result)
{
    char buf[48];
    rt_uint32_t sec;

    if (health_result == RT_NULL)
    {
        return;
    }

    sec = health_result->elapsed_sec;

    oled_update_line_cn(0, "用眼提醒", RT_TRUE);
    rt_snprintf(buf, sizeof(buf), "开灯%lu秒", (unsigned long)sec);
    oled_update_line_cn(1, buf, RT_TRUE);
    oled_update_line_cn(2, "请休息下", RT_TRUE);
    oled_update_line_cn(3, "按键返回", RT_TRUE);
}

static void app_show_screen(ui_page_t ui_page,
                            int menu_index,
                            int timer_index,
                            app_mode_t mode,
                            float lux,
                            rt_bool_t lux_ok,
                            int manual_brightness,
                            int manual_cct,
                            rt_bool_t timer_active,
                            rt_uint32_t timer_remaining_sec,
                            const eye_care_result_t *eye_result,
                            const health_reminder_result_t *health_result,
                            rt_bool_t reminder_allowed)
{
    /* 只有主页且用户最近没有操作时才显示提醒弹窗。 */
    if (reminder_allowed == RT_TRUE && health_result != RT_NULL && health_result->popup_active == RT_TRUE)
    {
        app_show_health_reminder_popup(health_result);
        return;
    }

    if (reminder_allowed == RT_TRUE && eye_result != RT_NULL && eye_result->popup_active == RT_TRUE)
    {
        app_show_eye_care_popup(eye_result);
        return;
    }

    switch (ui_page)
    {
    case UI_MENU:
        app_show_menu_screen(menu_index);
        break;
    case UI_EDIT_BRI:
        app_show_bri_edit_screen(manual_brightness);
        break;
    case UI_EDIT_CCT:
        app_show_cct_edit_screen(manual_cct);
        break;
    case UI_TIMER_SET:
        app_show_timer_set_screen(timer_index);
        break;
    case UI_EYE_CARE_SET:
        app_show_eye_care_set_screen((eye_result != RT_NULL) ? eye_result->enabled : RT_FALSE);
        break;
    case UI_HOME:
    default:
        app_show_home_screen(mode, lux, lux_ok, timer_active, timer_remaining_sec);
        break;
    }
}

static app_mode_t mode_from_saved_value(int value)
{
    if (value == (int)MODE_MANUAL_BRI)
    {
        return MODE_MANUAL_BRI;
    }

    if (value == (int)MODE_MANUAL_CCT)
    {
        return MODE_MANUAL_CCT;
    }

    return MODE_AUTO;
}

static void app_build_param(app_param_t *param,
                            app_mode_t mode,
                            int manual_brightness,
                            int manual_cct)
{
    if (param == RT_NULL)
    {
        return;
    }

    param->mode = (int)mode;
    param->manual_brightness = manual_brightness;
    param->manual_cct = manual_cct;
    app_param_sanitize(param);
}

static void app_request_param_save(app_param_t *pending_param,
                                   const app_param_t *saved_param,
                                   rt_bool_t *save_pending,
                                   rt_tick_t *save_request_tick,
                                   app_mode_t mode,
                                   int manual_brightness,
                                   int manual_cct)
{
    if (pending_param == RT_NULL || saved_param == RT_NULL ||
        save_pending == RT_NULL || save_request_tick == RT_NULL)
    {
        return;
    }

    app_build_param(pending_param, mode, manual_brightness, manual_cct);

    if (app_param_equal(pending_param, saved_param) == RT_FALSE)
    {
        *save_pending = RT_TRUE;
        *save_request_tick = rt_tick_get();
    }
}

static void app_process_param_save(app_param_t *pending_param,
                                   app_param_t *saved_param,
                                   rt_bool_t *save_pending,
                                   rt_tick_t save_request_tick)
{
    if (pending_param == RT_NULL || saved_param == RT_NULL || save_pending == RT_NULL)
    {
        return;
    }

    if (*save_pending == RT_FALSE)
    {
        return;
    }

    if (rt_tick_get() - save_request_tick < rt_tick_from_millisecond(APP_PARAM_SAVE_DELAY_MS))
    {
        return;
    }

    if (app_param_equal(pending_param, saved_param) == RT_TRUE)
    {
        *save_pending = RT_FALSE;
        return;
    }

    if (app_param_save(pending_param) == RT_EOK)
    {
        *saved_param = *pending_param;
    }
    else
    {
        rt_kprintf("app: parameter save failed\r\n");
    }

    *save_pending = RT_FALSE;
}

static void app_apply_lamp_output(rt_bool_t lamp_power,
                                  app_mode_t mode,
                                  rt_bool_t lux_ok,
                                  float lux,
                                  int manual_brightness,
                                  int manual_cct,
                                  const eye_care_result_t *eye_result,
                                  rt_bool_t suppress_reminder)
{
    int target_brightness;

    if (lamp_power == RT_FALSE)
    {
        pwm_led_set_percent(0);
        return;
    }

    if (mode == MODE_AUTO)
    {
        if (eye_result != RT_NULL &&
            eye_result->enabled == RT_TRUE &&
            eye_result->avg_valid == RT_TRUE)
        {
            target_brightness = eye_result->auto_brightness;
        }
        else if (lux_ok)
        {
            target_brightness = pwm_led_percent_from_lux(lux);
        }
        else
        {
            target_brightness = manual_brightness;
        }

        target_brightness = clamp_int(target_brightness, AUTO_MIN_BRIGHTNESS, AUTO_MAX_BRIGHTNESS);
    }
    else
    {
        target_brightness = manual_brightness;
    }

    if (suppress_reminder == RT_FALSE &&
        eye_result != RT_NULL &&
        eye_result->blink_active == RT_TRUE)
    {
        target_brightness += eye_result->blink_offset;
    }

    if (mode == MODE_AUTO)
    {
        target_brightness = clamp_int(target_brightness, AUTO_MIN_BRIGHTNESS, AUTO_MAX_BRIGHTNESS);
    }
    else
    {
        target_brightness = clamp_int(target_brightness, 0, 100);
    }

    pwm_led_set_percent_cct(target_brightness, manual_cct);
}

int main(void)
{
    app_mode_t mode = MODE_AUTO;
    ui_page_t ui_page = UI_HOME;
    int menu_index = 0;
    int timer_index = APP_TIMER_OFF;
    rt_bool_t timer_active = RT_FALSE;
    rt_uint32_t timer_remaining_sec = 0U;
    rt_tick_t last_timer_tick = 0;
    int manual_brightness = APP_PARAM_DEFAULT_BRIGHTNESS;
    int manual_cct = CCT_DEFAULT_K;
    float lux = 0.0f;
    rt_bool_t lux_ok = RT_FALSE;
    rt_bool_t oled_awake = RT_TRUE;
    rt_bool_t lamp_power = RT_TRUE;
    rt_tick_t last_oled_tick = 0;
    rt_tick_t last_input_tick = rt_tick_get();
    rt_tick_t last_encoder_step_tick = 0;
    eye_care_ctrl_t eye_care;
    const eye_care_result_t *eye_result = RT_NULL;
    rt_bool_t last_eye_popup_active = RT_FALSE;
    eye_care_popup_t last_eye_popup = EYE_POPUP_NONE;
    health_reminder_ctrl_t health_reminder;
    const health_reminder_result_t *health_result = RT_NULL;
    rt_bool_t last_health_popup_active = RT_FALSE;
    rt_bool_t reminder_allowed = RT_FALSE;

    app_param_t boot_param;
    app_param_t saved_param;
    app_param_t pending_param;
    rt_bool_t save_pending = RT_FALSE;
    rt_tick_t save_request_tick = 0;

    app_param_set_default(&boot_param);
    saved_param = boot_param;
    pending_param = boot_param;

    oled_init();
    oled_clear();
    oled_screen_cache_reset();
    oled_show_utf8_string(0, 0, "系统初始化");

    app_param_init();
    if (app_param_load(&boot_param) == RT_EOK)
    {
        oled_show_utf8_string(0, 2, "参数正常");
    }
    else
    {
        oled_show_utf8_string(0, 2, "参数默认");
    }

    app_param_sanitize(&boot_param);
    saved_param = boot_param;
    pending_param = boot_param;

    mode = mode_from_saved_value(boot_param.mode);
    manual_brightness = clamp_int(boot_param.manual_brightness, 0, 100);
    manual_cct = clamp_int(boot_param.manual_cct, CCT_WARM_K, CCT_COOL_K);
    eye_care_init(&eye_care, manual_brightness);
    eye_result = eye_care_get_result(&eye_care);
    health_reminder_init(&health_reminder);
    health_result = health_reminder_get_result(&health_reminder);

    if (pwm_led_init() != RT_EOK)
    {
        oled_show_utf8_string(0, 4, "灯带失败");
        return -RT_ERROR;
    }

    /* 用掉电保存的亮度和色温恢复灯光。自动模式下，后续会根据 BH1750 重新计算亮度。 */
    pwm_led_set_percent_cct(manual_brightness, manual_cct);

    if (encoder_init() != RT_EOK)
    {
        oled_show_utf8_string(0, 4, "编码器失败");
        return -RT_ERROR;
    }

    key_init();

    if (bh1750_init() != RT_EOK)
    {
        oled_show_utf8_string(0, 6, "传感失败");
        return -RT_ERROR;
    }

    oled_clear();
    oled_screen_cache_reset();
    last_input_tick = rt_tick_get();
    rt_kprintf("台灯系统启动：BH1750 双色温 PWM 菜单 护眼提醒\r\n");

    while (1)
    {
        int raw_delta;
        int delta;
        app_key_event_t key_event;
        rt_bool_t mode_key_pressed;
        rt_bool_t key_long_pressed;

        key_event = key_mode_scan();
        mode_key_pressed = (key_event == APP_KEY_EVENT_SHORT);
        key_long_pressed = (key_event == APP_KEY_EVENT_LONG);

        if (mode_key_pressed == RT_TRUE &&
            health_result != RT_NULL &&
            health_result->popup_active == RT_TRUE)
        {
            health_reminder_dismiss(&health_reminder);
            health_result = health_reminder_get_result(&health_reminder);
            mode_key_pressed = RT_FALSE;
            ui_force_redraw(&last_oled_tick);
        }

        if (bh1750_read_lux(&lux) == RT_EOK)
        {
            lux_ok = RT_TRUE;
        }
        else
        {
            lux_ok = RT_FALSE;
        }

        reminder_allowed = (timer_active == RT_FALSE) ? ui_reminder_allowed(ui_page, last_input_tick) : RT_FALSE;

        eye_care_process(&eye_care,
                         lux_ok,
                         lux,
                         (mode == MODE_AUTO) ? RT_TRUE : RT_FALSE,
                         lamp_power,
                         reminder_allowed);
        eye_result = eye_care_get_result(&eye_care);
        if (timer_active == RT_TRUE)
        {
            eye_care_clear_popup(&eye_care);
            eye_result = eye_care_get_result(&eye_care);
        }

        if (eye_result != RT_NULL)
        {
            if (reminder_allowed == RT_TRUE && eye_result->popup_active == RT_TRUE &&
                (last_eye_popup_active == RT_FALSE || last_eye_popup != eye_result->popup))
            {
                if (oled_awake == RT_FALSE)
                {
                    oled_display_on();
                    oled_awake = RT_TRUE;
                }
                last_input_tick = rt_tick_get();
                ui_force_redraw(&last_oled_tick);
            }
            else if (last_eye_popup_active == RT_TRUE && eye_result->popup_active == RT_FALSE)
            {
                ui_force_redraw(&last_oled_tick);
            }

            last_eye_popup_active = eye_result->popup_active;
            last_eye_popup = eye_result->popup;
        }

        if (timer_off_process(&timer_active, &timer_remaining_sec, &last_timer_tick) == RT_TRUE)
        {
            lamp_power = RT_FALSE;
            timer_index = APP_TIMER_OFF;
            ui_page = UI_HOME;
            ui_force_redraw(&last_oled_tick);
        }

        /* 每个循环都读取一次编码器，避免 AUTO 模式下累计旋转量 */
        raw_delta = encoder_get_delta();
        delta = encoder_delta_to_ui_step(raw_delta, &last_encoder_step_tick);

        /* 有按键或编码器动作时，记录操作时间，并自动唤醒 OLED */
        if ((key_event != APP_KEY_EVENT_NONE) || (raw_delta != 0))
        {
            oled_wake_up(&oled_awake, &last_input_tick, &last_oled_tick);
        }

        /* 关灯状态下旋转编码器：优先开灯，消耗本次旋转，不直接进入菜单。 */
        if ((lamp_power == RT_FALSE) && (raw_delta != 0))
        {
            lamp_power = RT_TRUE;
            timer_index = APP_TIMER_OFF;
            timer_off_cancel(&timer_active, &timer_remaining_sec, &last_timer_tick);
            app_apply_lamp_output(lamp_power, mode, lux_ok, lux, manual_brightness, manual_cct, eye_result, timer_active);

            raw_delta = 0;
            delta = 0;
            ui_page = UI_HOME;
            ui_force_redraw(&last_oled_tick);
        }

        /* PB0 长按：开灯/关灯。关灯时 OLED 同步熄屏；开灯时 OLED 同步点亮。 */
        if (key_long_pressed == RT_TRUE)
        {
            lamp_power = !lamp_power;
            timer_index = APP_TIMER_OFF;
            timer_off_cancel(&timer_active, &timer_remaining_sec, &last_timer_tick);
            app_apply_lamp_output(lamp_power, mode, lux_ok, lux, manual_brightness, manual_cct, eye_result, timer_active);

            ui_page = UI_HOME;

            if (lamp_power == RT_FALSE)
            {
                oled_display_off();
                oled_awake = RT_FALSE;
                oled_screen_cache_reset();
                last_oled_tick = 0;
            }
            else
            {
                oled_display_on();
                oled_awake = RT_TRUE;
                last_input_tick = rt_tick_get();
                ui_force_redraw(&last_oled_tick);
            }
        }

        /* OLED 菜单状态机：旋钮上下选择/调整，PB0 短按确认 */
        if (mode_key_pressed || delta != 0)
        {
            if (ui_page == UI_HOME)
            {
                if (mode_key_pressed)
                {
                    ui_page = UI_MENU;
                    ui_force_redraw(&last_oled_tick);
                }
                else if (delta != 0)
                {
                    if (mode == MODE_MANUAL_BRI)
                    {
                        manual_brightness += delta * BRIGHTNESS_STEP_PERCENT;
                        manual_brightness = clamp_int(manual_brightness, 0, 100);
                        if (lamp_power == RT_TRUE)
                        {
                            pwm_led_set_percent_cct(manual_brightness, manual_cct);
                        }

                        app_request_param_save(&pending_param,
                                               &saved_param,
                                               &save_pending,
                                               &save_request_tick,
                                               mode,
                                               manual_brightness,
                                               manual_cct);
                        last_oled_tick = 0;
                    }
                    else if (mode == MODE_MANUAL_CCT)
                    {
                        manual_cct += delta * CCT_STEP_K;
                        manual_cct = clamp_int(manual_cct, CCT_WARM_K, CCT_COOL_K);
                        if (lamp_power == RT_TRUE)
                        {
                            pwm_led_set_percent_cct(manual_brightness, manual_cct);
                        }

                        app_request_param_save(&pending_param,
                                               &saved_param,
                                               &save_pending,
                                               &save_request_tick,
                                               mode,
                                               manual_brightness,
                                               manual_cct);
                        last_oled_tick = 0;
                    }
                    /* 自动模式主页旋转无动作，避免误调光。 */
                }
            }
            else if (ui_page == UI_MENU)
            {
                if (delta != 0)
                {
                    menu_index = wrap_index(menu_index + delta, MENU_COUNT);
                    /* 菜单选择变化时不要整屏清除，只让显示函数更新变化的行 */
                    last_oled_tick = 0;
                }

                if (mode_key_pressed)
                {
                    if (menu_index == MENU_AUTO)
                    {
                        mode = MODE_AUTO;
                        if (lamp_power == RT_TRUE)
                        {
                            manual_brightness = pwm_led_get_percent();
                            manual_cct = pwm_led_get_cct();
                            eye_care_set_auto_brightness(&eye_care, manual_brightness);
                        }
                        ui_page = UI_HOME;

                        app_request_param_save(&pending_param,
                                               &saved_param,
                                               &save_pending,
                                               &save_request_tick,
                                               mode,
                                               manual_brightness,
                                               manual_cct);
                    }
                    else if (menu_index == MENU_BRI)
                    {
                        mode = MODE_MANUAL_BRI;
                        if (lamp_power == RT_TRUE)
                        {
                            manual_brightness = pwm_led_get_percent();
                            manual_cct = pwm_led_get_cct();
                        }
                        ui_page = UI_HOME;

                        app_request_param_save(&pending_param,
                                               &saved_param,
                                               &save_pending,
                                               &save_request_tick,
                                               mode,
                                               manual_brightness,
                                               manual_cct);
                    }
                    else if (menu_index == MENU_CCT)
                    {
                        mode = MODE_MANUAL_CCT;
                        if (lamp_power == RT_TRUE)
                        {
                            manual_brightness = pwm_led_get_percent();
                            manual_cct = pwm_led_get_cct();
                        }
                        ui_page = UI_HOME;

                        app_request_param_save(&pending_param,
                                               &saved_param,
                                               &save_pending,
                                               &save_request_tick,
                                               mode,
                                               manual_brightness,
                                               manual_cct);
                    }
                    else if (menu_index == MENU_TIMER)
                    {
                        ui_page = UI_TIMER_SET;
                    }
                    else if (menu_index == MENU_EYE_CARE)
                    {
                        ui_page = UI_EYE_CARE_SET;
                    }
                    else
                    {
                        ui_page = UI_HOME;
                    }

                    ui_force_redraw(&last_oled_tick);
                }
            }
            else if (ui_page == UI_EDIT_BRI)
            {
                if (delta != 0)
                {
                    manual_brightness += delta * BRIGHTNESS_STEP_PERCENT;
                    manual_brightness = clamp_int(manual_brightness, 0, 100);
                    if (lamp_power == RT_TRUE)
                    {
                        pwm_led_set_percent(manual_brightness);
                    }

                    app_request_param_save(&pending_param,
                                           &saved_param,
                                           &save_pending,
                                           &save_request_tick,
                                           mode,
                                           manual_brightness,
                                           manual_cct);
                    last_oled_tick = 0;
                }

                if (mode_key_pressed)
                {
                    ui_page = UI_HOME;
                    ui_force_redraw(&last_oled_tick);
                }
            }
            else if (ui_page == UI_EDIT_CCT)
            {
                if (delta != 0)
                {
                    manual_cct += delta * CCT_STEP_K;
                    manual_cct = clamp_int(manual_cct, CCT_WARM_K, CCT_COOL_K);
                    if (lamp_power == RT_TRUE)
                    {
                        pwm_led_set_color_temp(manual_cct);
                    }

                    app_request_param_save(&pending_param,
                                           &saved_param,
                                           &save_pending,
                                           &save_request_tick,
                                           mode,
                                           manual_brightness,
                                           manual_cct);
                    last_oled_tick = 0;
                }

                if (mode_key_pressed)
                {
                    ui_page = UI_HOME;
                    ui_force_redraw(&last_oled_tick);
                }
            }
            else if (ui_page == UI_EYE_CARE_SET)
            {
                if (delta != 0)
                {
                    eye_care_set_enable(&eye_care, eye_care_is_enable(&eye_care) ? RT_FALSE : RT_TRUE);
                    eye_result = eye_care_get_result(&eye_care);
                    last_oled_tick = 0;
                }

                if (mode_key_pressed)
                {
                    ui_page = UI_HOME;
                    ui_force_redraw(&last_oled_tick);
                }
            }
            else if (ui_page == UI_TIMER_SET)
            {
                if (delta != 0)
                {
                    timer_index = wrap_index(timer_index + delta, APP_TIMER_COUNT);
                    last_oled_tick = 0;
                }

                if (mode_key_pressed)
                {
                    if (timer_index == APP_TIMER_OFF)
                    {
                        timer_off_cancel(&timer_active, &timer_remaining_sec, &last_timer_tick);
                    }
                    else
                    {
                        lamp_power = RT_TRUE;
                        timer_off_start((app_timer_item_t)timer_index,
                                        &timer_active,
                                        &timer_remaining_sec,
                                        &last_timer_tick);
                    }

                    ui_page = UI_HOME;
                    ui_force_redraw(&last_oled_tick);
                }
            }
        }

        reminder_allowed = (timer_active == RT_FALSE) ? ui_reminder_allowed(ui_page, last_input_tick) : RT_FALSE;

        health_reminder_process(&health_reminder,
                                (timer_active == RT_TRUE) ? RT_FALSE : lamp_power,
                                reminder_allowed);
        health_result = health_reminder_get_result(&health_reminder);

        if (health_result != RT_NULL)
        {
            if (reminder_allowed == RT_TRUE && health_result->popup_active == RT_TRUE &&
                last_health_popup_active == RT_FALSE)
            {
                if (oled_awake == RT_FALSE)
                {
                    oled_display_on();
                    oled_awake = RT_TRUE;
                }
                last_input_tick = rt_tick_get();
                ui_force_redraw(&last_oled_tick);
            }
            else if (last_health_popup_active == RT_TRUE && health_result->popup_active == RT_FALSE)
            {
                ui_force_redraw(&last_oled_tick);
            }
            last_health_popup_active = health_result->popup_active;
        }

        /* 根据当前开关状态、模式和光照值输出灯光。
         * 关灯状态下保持 PWM 为 0，避免自动模式下一轮循环又把灯点亮。
         */
        app_apply_lamp_output(lamp_power, mode, lux_ok, lux, manual_brightness, manual_cct, eye_result, timer_active);

        app_process_param_save(&pending_param,
                               &saved_param,
                               &save_pending,
                               save_request_tick);

        /* 无操作超过设定时间后关闭 OLED 显示 */
        oled_check_sleep(&oled_awake, last_input_tick);

        /* OLED 熄屏时不刷新，但台灯控制逻辑和参数保存逻辑继续运行 */
        if (oled_awake == RT_TRUE)
        {
            if (rt_tick_get() - last_oled_tick >= rt_tick_from_millisecond(OLED_REFRESH_MS))
            {
                last_oled_tick = rt_tick_get();
                app_show_screen(ui_page,
                                menu_index,
                                timer_index,
                                mode,
                                lux,
                                lux_ok,
                                manual_brightness,
                                manual_cct,
                                timer_active,
                                timer_remaining_sec,
                                eye_result,
                                health_result,
                                ((timer_active == RT_FALSE) ? ui_reminder_allowed(ui_page, last_input_tick) : RT_FALSE));
            }
        }

        rt_thread_mdelay(CONTROL_LOOP_MS);
    }
}
