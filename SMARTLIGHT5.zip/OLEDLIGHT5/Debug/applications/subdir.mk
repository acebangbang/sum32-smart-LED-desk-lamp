################################################################################
# 自动生成的文件。不要编辑！
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../applications/app_encoder.c \
../applications/app_eye_care.c \
../applications/app_health_reminder.c \
../applications/app_key.c \
../applications/app_param.c \
../applications/app_pwm_led.c \
../applications/bh1750.c \
../applications/main.c \
../applications/oled.c 

OBJS += \
./applications/app_encoder.o \
./applications/app_eye_care.o \
./applications/app_health_reminder.o \
./applications/app_key.o \
./applications/app_param.o \
./applications/app_pwm_led.o \
./applications/bh1750.o \
./applications/main.o \
./applications/oled.o 

C_DEPS += \
./applications/app_encoder.d \
./applications/app_eye_care.d \
./applications/app_health_reminder.d \
./applications/app_key.d \
./applications/app_param.d \
./applications/app_pwm_led.d \
./applications/bh1750.d \
./applications/main.d \
./applications/oled.d 


# Each subdirectory must supply rules for building sources it contributes
applications/%.o: ../applications/%.c
	arm-none-eabi-gcc -mcpu=cortex-m4 -mthumb -mfloat-abi=hard -mfpu=fpv4-sp-d16 -O0 -ffunction-sections -fdata-sections -Wall  -g -gdwarf-2 -DSOC_FAMILY_STM32 -DSOC_SERIES_STM32F4 -DUSE_HAL_DRIVER -DSTM32F407xx -I"C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT5\drivers" -I"C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT5\drivers\include" -I"C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT5\drivers\include\config" -I"C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT5\libraries\CMSIS\Device\ST\STM32F4xx\Include" -I"C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT5\libraries\CMSIS\Include" -I"C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT5\libraries\CMSIS\RTOS\Template" -I"C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT5\libraries\STM32F4xx_HAL_Driver\Inc" -I"C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT5\libraries\STM32F4xx_HAL_Driver\Inc\Legacy" -I"C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT5" -I"C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT5\applications" -I"C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT5" -I"C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT5\applications" -I"C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT5\cubemx\Inc" -I"C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT5\cubemx" -I"C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT5\rt-thread\components\drivers\include" -I"C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT5\rt-thread\components\finsh" -I"C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT5\rt-thread\components\libc\compilers\common\include" -I"C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT5\rt-thread\components\libc\compilers\newlib" -I"C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT5\rt-thread\components\libc\posix\io\epoll" -I"C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT5\rt-thread\components\libc\posix\io\eventfd" -I"C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT5\rt-thread\components\libc\posix\io\poll" -I"C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT5\rt-thread\components\libc\posix\ipc" -I"C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT5\rt-thread\include" -I"C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT5\rt-thread\libcpu\arm\common" -I"C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT5\rt-thread\libcpu\arm\cortex-m4" -include"C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT5\rtconfig_preinc.h" -std=gnu11 -MMD -MP -MF"$(@:%.o=%.d)" -MT"$(@)" -c -o "$@" "$<"

