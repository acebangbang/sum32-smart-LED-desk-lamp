libraries/STM32F4xx_HAL_Driver/Src/stm32f4xx_ll_crc.o: \
 ../libraries/STM32F4xx_HAL_Driver/Src/stm32f4xx_ll_crc.c \
 C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\rtconfig_preinc.h

C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\rtconfig_preinc.h:
