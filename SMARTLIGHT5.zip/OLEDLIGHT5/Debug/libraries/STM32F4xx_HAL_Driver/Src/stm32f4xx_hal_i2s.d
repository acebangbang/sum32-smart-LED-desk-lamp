libraries/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_i2s.o: \
 ../libraries/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_i2s.c \
 C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\rtconfig_preinc.h \
 C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\libraries\STM32F4xx_HAL_Driver\Inc/stm32f4xx_hal.h \
 C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\cubemx\Inc/stm32f4xx_hal_conf.h \
 C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\libraries\STM32F4xx_HAL_Driver\Inc/stm32f4xx_hal_rcc.h \
 C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\libraries\STM32F4xx_HAL_Driver\Inc/stm32f4xx_hal_def.h \
 C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\libraries\CMSIS\Device\ST\STM32F4xx\Include/stm32f4xx.h \
 C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\libraries\CMSIS\Device\ST\STM32F4xx\Include/stm32f407xx.h \
 C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\libraries\CMSIS\Include/core_cm4.h \
 C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\libraries\CMSIS\Include/cmsis_version.h \
 C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\libraries\CMSIS\Include/cmsis_compiler.h \
 C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\libraries\CMSIS\Include/cmsis_gcc.h \
 C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\libraries\CMSIS\Include/mpu_armv7.h \
 C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\libraries\CMSIS\Device\ST\STM32F4xx\Include/system_stm32f4xx.h \
 C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\libraries\STM32F4xx_HAL_Driver\Inc/Legacy/stm32_hal_legacy.h \
 C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\libraries\STM32F4xx_HAL_Driver\Inc/stm32f4xx_hal_rcc_ex.h \
 C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\libraries\STM32F4xx_HAL_Driver\Inc/stm32f4xx_hal_gpio.h \
 C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\libraries\STM32F4xx_HAL_Driver\Inc/stm32f4xx_hal_gpio_ex.h \
 C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\libraries\STM32F4xx_HAL_Driver\Inc/stm32f4xx_hal_exti.h \
 C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\libraries\STM32F4xx_HAL_Driver\Inc/stm32f4xx_hal_dma.h \
 C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\libraries\STM32F4xx_HAL_Driver\Inc/stm32f4xx_hal_dma_ex.h \
 C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\libraries\STM32F4xx_HAL_Driver\Inc/stm32f4xx_hal_cortex.h \
 C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\libraries\STM32F4xx_HAL_Driver\Inc/stm32f4xx_hal_flash.h \
 C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\libraries\STM32F4xx_HAL_Driver\Inc/stm32f4xx_hal_flash_ex.h \
 C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\libraries\STM32F4xx_HAL_Driver\Inc/stm32f4xx_hal_flash_ramfunc.h \
 C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\libraries\STM32F4xx_HAL_Driver\Inc/stm32f4xx_hal_i2c.h \
 C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\libraries\STM32F4xx_HAL_Driver\Inc/stm32f4xx_hal_i2c_ex.h \
 C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\libraries\STM32F4xx_HAL_Driver\Inc/stm32f4xx_hal_pwr.h \
 C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\libraries\STM32F4xx_HAL_Driver\Inc/stm32f4xx_hal_pwr_ex.h \
 C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\libraries\STM32F4xx_HAL_Driver\Inc/stm32f4xx_hal_tim.h \
 C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\libraries\STM32F4xx_HAL_Driver\Inc/stm32f4xx_hal_tim_ex.h \
 C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\libraries\STM32F4xx_HAL_Driver\Inc/stm32f4xx_hal_uart.h

C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\rtconfig_preinc.h:

C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\libraries\STM32F4xx_HAL_Driver\Inc/stm32f4xx_hal.h:

C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\cubemx\Inc/stm32f4xx_hal_conf.h:

C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\libraries\STM32F4xx_HAL_Driver\Inc/stm32f4xx_hal_rcc.h:

C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\libraries\STM32F4xx_HAL_Driver\Inc/stm32f4xx_hal_def.h:

C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\libraries\CMSIS\Device\ST\STM32F4xx\Include/stm32f4xx.h:

C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\libraries\CMSIS\Device\ST\STM32F4xx\Include/stm32f407xx.h:

C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\libraries\CMSIS\Include/core_cm4.h:

C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\libraries\CMSIS\Include/cmsis_version.h:

C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\libraries\CMSIS\Include/cmsis_compiler.h:

C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\libraries\CMSIS\Include/cmsis_gcc.h:

C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\libraries\CMSIS\Include/mpu_armv7.h:

C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\libraries\CMSIS\Device\ST\STM32F4xx\Include/system_stm32f4xx.h:

C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\libraries\STM32F4xx_HAL_Driver\Inc/Legacy/stm32_hal_legacy.h:

C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\libraries\STM32F4xx_HAL_Driver\Inc/stm32f4xx_hal_rcc_ex.h:

C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\libraries\STM32F4xx_HAL_Driver\Inc/stm32f4xx_hal_gpio.h:

C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\libraries\STM32F4xx_HAL_Driver\Inc/stm32f4xx_hal_gpio_ex.h:

C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\libraries\STM32F4xx_HAL_Driver\Inc/stm32f4xx_hal_exti.h:

C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\libraries\STM32F4xx_HAL_Driver\Inc/stm32f4xx_hal_dma.h:

C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\libraries\STM32F4xx_HAL_Driver\Inc/stm32f4xx_hal_dma_ex.h:

C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\libraries\STM32F4xx_HAL_Driver\Inc/stm32f4xx_hal_cortex.h:

C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\libraries\STM32F4xx_HAL_Driver\Inc/stm32f4xx_hal_flash.h:

C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\libraries\STM32F4xx_HAL_Driver\Inc/stm32f4xx_hal_flash_ex.h:

C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\libraries\STM32F4xx_HAL_Driver\Inc/stm32f4xx_hal_flash_ramfunc.h:

C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\libraries\STM32F4xx_HAL_Driver\Inc/stm32f4xx_hal_i2c.h:

C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\libraries\STM32F4xx_HAL_Driver\Inc/stm32f4xx_hal_i2c_ex.h:

C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\libraries\STM32F4xx_HAL_Driver\Inc/stm32f4xx_hal_pwr.h:

C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\libraries\STM32F4xx_HAL_Driver\Inc/stm32f4xx_hal_pwr_ex.h:

C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\libraries\STM32F4xx_HAL_Driver\Inc/stm32f4xx_hal_tim.h:

C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\libraries\STM32F4xx_HAL_Driver\Inc/stm32f4xx_hal_tim_ex.h:

C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\libraries\STM32F4xx_HAL_Driver\Inc/stm32f4xx_hal_uart.h:
