rt-thread/libcpu/arm/common/div0.o: ../rt-thread/libcpu/arm/common/div0.c \
 C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\rtconfig_preinc.h

C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\rtconfig_preinc.h:
