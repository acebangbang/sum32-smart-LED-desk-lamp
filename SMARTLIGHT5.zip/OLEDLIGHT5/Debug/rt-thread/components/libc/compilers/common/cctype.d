rt-thread/components/libc/compilers/common/cctype.o: \
 ../rt-thread/components/libc/compilers/common/cctype.c \
 C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\rtconfig_preinc.h \
 C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\rt-thread\components\libc\compilers\common\include/posix/ctype.h

C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\rtconfig_preinc.h:

C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\rt-thread\components\libc\compilers\common\include/posix/ctype.h:
