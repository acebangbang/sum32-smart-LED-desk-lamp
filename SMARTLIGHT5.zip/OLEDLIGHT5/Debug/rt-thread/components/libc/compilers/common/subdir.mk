################################################################################
# 自动生成的文件。不要编辑！
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../rt-thread/components/libc/compilers/common/cctype.c \
../rt-thread/components/libc/compilers/common/cstdlib.c \
../rt-thread/components/libc/compilers/common/cstring.c \
../rt-thread/components/libc/compilers/common/ctime.c \
../rt-thread/components/libc/compilers/common/cunistd.c \
../rt-thread/components/libc/compilers/common/cwchar.c 

OBJS += \
./rt-thread/components/libc/compilers/common/cctype.o \
./rt-thread/components/libc/compilers/common/cstdlib.o \
./rt-thread/components/libc/compilers/common/cstring.o \
./rt-thread/components/libc/compilers/common/ctime.o \
./rt-thread/components/libc/compilers/common/cunistd.o \
./rt-thread/components/libc/compilers/common/cwchar.o 

C_DEPS += \
./rt-thread/components/libc/compilers/common/cctype.d \
./rt-thread/components/libc/compilers/common/cstdlib.d \
./rt-thread/components/libc/compilers/common/cstring.d \
./rt-thread/components/libc/compilers/common/ctime.d \
./rt-thread/components/libc/compilers/common/cunistd.d \
./rt-thread/components/libc/compilers/common/cwchar.d 


# Each subdirectory must supply rules for building sources it contributes
rt-thread/components/libc/compilers/common/%.o: ../rt-thread/components/libc/compilers/common/%.c
	arm-none-eabi-gcc -mcpu=cortex-m4 -mthumb -mfloat-abi=hard -mfpu=fpv4-sp-d16 -O0 -ffunction-sections -fdata-sections -Wall  -g -gdwarf-2 -DSOC_FAMILY_STM32 -DSOC_SERIES_STM32F4 -DUSE_HAL_DRIVER -DSTM32F407xx -I"C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT5\drivers" -I"C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT5\drivers\include" -I"C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT5\drivers\include\config" -I"C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT5\libraries\CMSIS\Device\ST\STM32F4xx\Include" -I"C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT5\libraries\CMSIS\Include" -I"C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT5\libraries\CMSIS\RTOS\Template" -I"C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT5\libraries\STM32F4xx_HAL_Driver\Inc" -I"C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT5\libraries\STM32F4xx_HAL_Driver\Inc\Legacy" -I"C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT5" -I"C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT5\applications" -I"C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT5" -I"C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT5\applications" -I"C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT5\cubemx\Inc" -I"C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT5\cubemx" -I"C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT5\rt-thread\components\drivers\include" -I"C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT5\rt-thread\components\finsh" -I"C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT5\rt-thread\components\libc\compilers\common\include" -I"C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT5\rt-thread\components\libc\compilers\newlib" -I"C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT5\rt-thread\components\libc\posix\io\epoll" -I"C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT5\rt-thread\components\libc\posix\io\eventfd" -I"C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT5\rt-thread\components\libc\posix\io\poll" -I"C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT5\rt-thread\components\libc\posix\ipc" -I"C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT5\rt-thread\include" -I"C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT5\rt-thread\libcpu\arm\common" -I"C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT5\rt-thread\libcpu\arm\cortex-m4" -include"C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT5\rtconfig_preinc.h" -std=gnu11 -MMD -MP -MF"$(@:%.o=%.d)" -MT"$(@)" -c -o "$@" "$<"

