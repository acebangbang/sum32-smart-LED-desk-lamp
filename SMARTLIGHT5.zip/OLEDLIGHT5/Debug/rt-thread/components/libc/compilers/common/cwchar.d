rt-thread/components/libc/compilers/common/cwchar.o: \
 ../rt-thread/components/libc/compilers/common/cwchar.c \
 C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\rtconfig_preinc.h \
 C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\rt-thread\components\libc\compilers\common\include/posix/wchar.h

C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\rtconfig_preinc.h:

C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\rt-thread\components\libc\compilers\common\include/posix/wchar.h:
