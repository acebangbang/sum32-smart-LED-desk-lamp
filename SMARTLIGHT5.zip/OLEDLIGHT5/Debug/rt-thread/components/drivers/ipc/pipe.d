rt-thread/components/drivers/ipc/pipe.o: \
 ../rt-thread/components/drivers/ipc/pipe.c \
 C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\rtconfig_preinc.h \
 C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\rt-thread\include/rthw.h \
 C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\rt-thread\include/rtdef.h \
 C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\rt-thread\include/rtsched.h \
 C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\rt-thread\include/rttypes.h \
 C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3/rtconfig.h \
 C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\rt-thread\include/rtcompiler.h \
 C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\rt-thread\components\drivers\include/rtdevice.h \
 C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\rt-thread\include/rtthread.h \
 C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\rt-thread\include/rtservice.h \
 C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\rt-thread\include/rtm.h \
 C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\rt-thread\include/rtatomic.h \
 C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\rt-thread\include/rtklibc.h \
 C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\rt-thread\components\finsh/finsh.h \
 C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\rt-thread\components\drivers\include/drivers/core/driver.h \
 C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\rt-thread\components\drivers\include/drivers/core/bus.h \
 C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\rt-thread\components\drivers\include/drivers/classes/block.h \
 C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\rt-thread\components\drivers\include/drivers/classes/char.h \
 C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\rt-thread\components\drivers\include/drivers/classes/graphic.h \
 C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\rt-thread\components\drivers\include/drivers/classes/mtd.h \
 C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\rt-thread\components\drivers\include/drivers/classes/net.h \
 C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\rt-thread\components\drivers\include/ipc/ringbuffer.h \
 C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\rt-thread\components\drivers\include/ipc/completion.h \
 C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\rt-thread\components\drivers\include/ipc/dataqueue.h \
 C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\rt-thread\components\drivers\include/ipc/workqueue.h \
 C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\rt-thread\components\drivers\include/ipc/condvar.h \
 C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\rt-thread\components\drivers\include/ipc/waitqueue.h \
 C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\rt-thread\components\drivers\include/ipc/pipe.h \
 C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\rt-thread\components\drivers\include/ipc/condvar.h \
 C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\rt-thread\components\drivers\include/ipc/poll.h \
 C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\rt-thread\components\drivers\include/ipc/ringblk_buf.h \
 C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\rt-thread\components\drivers\include/drivers/serial.h \
 C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\rt-thread\components\drivers\include/drivers/i2c.h \
 C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\rt-thread\components\drivers\include/drivers/i2c_dev.h \
 C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\rt-thread\components\drivers\include/drivers/i2c-bit-ops.h \
 C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\rt-thread\components\drivers\include/drivers/pin.h \
 C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\rt-thread\components\drivers\include/drivers/rt_drv_pwm.h \
 C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\rt-thread\components\drivers\include/ipc/condvar.h

C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\rtconfig_preinc.h:

C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\rt-thread\include/rthw.h:

C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\rt-thread\include/rtdef.h:

C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\rt-thread\include/rtsched.h:

C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\rt-thread\include/rttypes.h:

C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3/rtconfig.h:

C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\rt-thread\include/rtcompiler.h:

C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\rt-thread\components\drivers\include/rtdevice.h:

C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\rt-thread\include/rtthread.h:

C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\rt-thread\include/rtservice.h:

C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\rt-thread\include/rtm.h:

C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\rt-thread\include/rtatomic.h:

C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\rt-thread\include/rtklibc.h:

C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\rt-thread\components\finsh/finsh.h:

C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\rt-thread\components\drivers\include/drivers/core/driver.h:

C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\rt-thread\components\drivers\include/drivers/core/bus.h:

C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\rt-thread\components\drivers\include/drivers/classes/block.h:

C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\rt-thread\components\drivers\include/drivers/classes/char.h:

C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\rt-thread\components\drivers\include/drivers/classes/graphic.h:

C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\rt-thread\components\drivers\include/drivers/classes/mtd.h:

C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\rt-thread\components\drivers\include/drivers/classes/net.h:

C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\rt-thread\components\drivers\include/ipc/ringbuffer.h:

C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\rt-thread\components\drivers\include/ipc/completion.h:

C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\rt-thread\components\drivers\include/ipc/dataqueue.h:

C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\rt-thread\components\drivers\include/ipc/workqueue.h:

C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\rt-thread\components\drivers\include/ipc/condvar.h:

C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\rt-thread\components\drivers\include/ipc/waitqueue.h:

C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\rt-thread\components\drivers\include/ipc/pipe.h:

C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\rt-thread\components\drivers\include/ipc/condvar.h:

C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\rt-thread\components\drivers\include/ipc/poll.h:

C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\rt-thread\components\drivers\include/ipc/ringblk_buf.h:

C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\rt-thread\components\drivers\include/drivers/serial.h:

C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\rt-thread\components\drivers\include/drivers/i2c.h:

C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\rt-thread\components\drivers\include/drivers/i2c_dev.h:

C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\rt-thread\components\drivers\include/drivers/i2c-bit-ops.h:

C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\rt-thread\components\drivers\include/drivers/pin.h:

C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\rt-thread\components\drivers\include/drivers/rt_drv_pwm.h:

C:\rtthread-studio\RT-ThreadStudio\workspace\OLEDLIGHT3\rt-thread\components\drivers\include/ipc/condvar.h:
